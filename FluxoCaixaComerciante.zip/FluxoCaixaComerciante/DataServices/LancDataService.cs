﻿using AutoMapper;
using FluxoCaixa.Interfaces.DataServices;
using FluxoCaixa.Interfaces.Repositories;
using FluxoCaixa.Models;
using FluxoCaixa.Models.AbsModels;
using FluxoCaixa.Models.DTOs;
using FluxoCaixa.Models.Enums;
using FluxoCaixa.Models.GlobalFunction;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FluxoCaixa.DataServices
{
    /// <summary>
    /// Implementation of interface ILancDataService
    /// </summary>
    public class LancDataService : ILancDataService
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        protected readonly ILancRepository _repo;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="repo"></param>
        /// <param name="mapper"></param>
        public LancDataService(ILancRepository repo, IMapper mapper)
        {
            _mapper = mapper;
            _repo = repo;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<LancDto> Get(int id)
        {
            Lanc lanc = await _repo.GetByIdAsync(id);

            if (lanc == null)
                return null;

            return _mapper.Map<LancDto>(lanc);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lancDto"></param>
        /// <returns></returns>
        public async Task<LancDto> Add(LancDto lancDto)
        {
            _ = new Lanc();

            Lanc lanc = _mapper.Map<Lanc>(lancDto);
            await _repo.SaveAsync(lanc);

            return _mapper.Map<LancDto>(lanc);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lancDto"></param>
        /// <returns></returns>
        public async Task<LancDto> Update(LancDto lancDto)
        {
            Lanc lanc = _mapper.Map<Lanc>(lancDto);
            await _repo.SaveAsync(lanc);

            return _mapper.Map<LancDto>(lanc);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<ICollection<LancDto>> List()
        {
            ICollection<Lanc> list = await _repo.GetAllAsync();
            return _mapper.Map<ICollection<LancDto>>(list);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<ICollection<LancDto>> ListConsolated(DateTime date)
        {
            ICollection<Lanc> list = await _repo.GetByFilterAsync(c => c.DateLanc.Date == date);
            return _mapper.Map<ICollection<LancDto>>(list);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lancDto"></param>
        /// <returns></returns>
        public async Task<bool> DuplicateExists(LancDto lancDto)
        {
            if (lancDto.Id == 0)
                return await _repo.ExistDataAsync(c => c.DescLanc.ToUpper() == lancDto.DescLanc.ToUpper());
            else
                return await _repo.ExistDataAsync(c => c.Id != lancDto.Id && c.DescLanc.ToUpper() == lancDto.DescLanc.ToUpper());
        }
    }
}