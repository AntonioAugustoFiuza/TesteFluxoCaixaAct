﻿using AutoMapper;
using FluxoCaixa.Interfaces.DataServices;
using FluxoCaixa.Interfaces.Repositories;
using FluxoCaixa.Models;
using FluxoCaixa.Models.Constants;
using FluxoCaixa.Models.DTOs;
using FluxoCaixa.Models.GlobalFunction;
using System.Collections.ObjectModel;

namespace FluxoCaixa.DataServices
{
    /// <summary>
    /// Class User Service
    /// </summary>
    public class UserDataService : IUserDataService
    {
        /// <summary>
        /// Mapper
        /// </summary>
        protected readonly IMapper _mapper;
        /// <summary>
        /// User Repository
        /// </summary>
        protected readonly IUserRepository _repo;
        /// <summary>
        /// User Role Repository
        /// </summary>
        private readonly IUserRoleRepository _repoUserRole;

        /// <summary>
        /// Default constructor
        /// </summary>
        /// <param name="mapper">Mapper</param>
        /// <param name="repo">User Repository</param>
        /// <param name="repoUserRole">User Role Repository</param>
        public UserDataService(
            IUserRepository repo,
            IMapper mapper,
            IUserRoleRepository repoUserRole
            )
        {
            _repo = repo;
            _mapper = mapper;
            _repoUserRole = repoUserRole;
        }

        /// <summary>
        /// Get user dto by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<UserDto> GetById(int id)
        {

            User user = await _repo.GetOneByFilterAsync(c => c.Id == id,
                new Collection<string>() { "UserRole", "UserRegions.Region", "UserSites.Site", "UserBuildings.Building" }, null, false, true);

            if (user == null)
                return null;

            UserDto userDto = MappingUserToUserDto(user);

            return userDto;
        }

        /// <summary>
        /// Get user dto by id to info
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<UserDto> GetUserInfoById(int id)
        {
            return await _repo.GetUserInfoById(id);
        }

        /// <summary>
        /// Get by network user
        /// </summary>
        /// <param name="networkUser">Network User</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> GetByNetworkUser(string networkUser)
        {
            User user = await _repo.GetOneByFilterAsync(c => c.NetworkUser.ToUpper() == networkUser.ToUpper(),
                new Collection<string>() { "UserRole", "UserRegions.Region", "UserSites.Site", "UserBuildings.Building" }, null, false, true);

            if (user == null)
                return null;

            return MappingUserToUserDto(user);
        }

        /// <summary>
        /// Get user by Email
        /// </summary>
        /// <param name="email">Email</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> GetUserByEmail(string email)
        {
            User user = await _repo.GetOneByFilterAsync(c => c.Email.ToUpper() == email.ToUpper(),
                new Collection<string>() { "UserRole", "UserRegions.Region", "UserSites.Site", "UserBuildings.Building" }, null, false, true);

            if (user == null)
                return null;

            return MappingUserToUserDto(user);
        }

        /// <summary>
        /// Check if user exist
        /// </summary>
        /// <param name="userFilterDto">UserFilterDto</param>
        /// <returns>bool</returns>
        public async Task<bool> CheckIfExist(UserFilterDto userFilterDto)
        {
            bool result = await _repo.CheckIfExist(userFilterDto);
            return result;
        }

        /// <summary>
        /// Asynchronous method to get User by filters
        /// </summary>
        /// <param name="userFilterDto">UserFilterDto</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> GetUserByNetworkAndFilters(UserFilterDto userFilterDto)
        {
            UserDto user = await _repo.GetUserByNetworkAndFilters(userFilterDto);

            return user;
        }

        /// <summary>
        /// Asynchronous method to add new user
        /// </summary>
        /// <param name="userDto">User DTO</param>
        /// <returns>User DTO</returns>
        public async Task<UserDto> Add(UserDto userDto)
        {
            _ = new User();

            User user = _mapper.Map<User>(userDto);

            UserRole userRole = await _repoUserRole.GetByIdAsync(user.UserRoleId);
            userDto.UserRoleDesc = userRole.Description;
            
            await _repo.SaveAsync(user);

            return _mapper.Map<UserDto>(user);
        }

        /// <summary>
        /// Asynchronous method to update a existing user
        /// </summary>
        /// <param name="userDto">User DTO</param>
        /// <returns>User DTO</returns>
        public async Task<UserDto> Update(UserDto userDto)
        {
            User userToUpdate = await _repo.GetOneByFilterAsync(c => c.Id == userDto.Id,
                new Collection<string>() { "UserRole" });

            if (userToUpdate == null)
                return null;

            UserDto oldUser = _mapper.Map<UserDto>(userToUpdate);

            userToUpdate = MappingUserDtoToUser(userDto);

            await _repo.SaveAsync(userToUpdate);

            var userRole = await _repoUserRole.GetOneByFilterAsync(x => x.Id == userDto.UserRoleId);
            userDto.UserRoleDesc = userRole.Description;

            return userDto;
        }

        /// <summary>
        /// Method to active user
        /// </summary>
        /// <param name="id">Id</param>
        /// <param name="changeReason">ChangeReason</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> Activate(int id, string changeReason)
        {
            User user = await _repo.GetOneByFilterAsync(x => x.Id == id,
                new Collection<string> { "UserRole" });

            if (user == null)
                return null;

            UserDto oldUser = _mapper.Map<UserDto>(user);

            user.Active = true;
            UserDto userDto = _mapper.Map<UserDto>(user);

            await _repo.SaveAsync(user);

            return userDto;
        }

        /// <summary>
        /// Method to inactive user
        /// </summary>
        /// <param name="id">Id</param>
        /// <param name="changeReason">Change reason</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> Inactivate(int id, string changeReason)
        {
            User user = await _repo.GetOneByFilterAsync(x => x.Id == id,
                new Collection<string> { "UserRole" });

            if (user == null)
                return null;

            UserDto oldUser = _mapper.Map<UserDto>(user);

            user.Active = false;
            UserDto userDto = _mapper.Map<UserDto>(user);

            await _repo.SaveAsync(user);

            return userDto;
        }

        /// <summary>
        /// Method to mapping user to user dto
        /// </summary>
        /// <param name="user">User</param>
        /// <returns>UserDto</returns>
        private UserDto MappingUserToUserDto(User user)
        {
            UserDto userDto = _mapper.Map<UserDto>(user);
            userDto.UserRoleDesc = user.UserRole.Description;

            return userDto;
        }

        /// <summary>
        /// Method to mapping user dto to user
        /// </summary>
        /// <param name="userDto">UserDto</param>
        /// <returns>User</returns>
        private User MappingUserDtoToUser(UserDto userDto)
        {
            User user = _mapper.Map<User>(userDto);

            return user;
        }

        /// <summary>
        /// Method to list all user
        /// </summary>
        /// <returns>ICollection - UserDto</returns>
        public async Task<ICollection<UserDto>> List()
        {
            ICollection<User> list = await _repo.GetAllAsync(
                new Collection<string>() { "UserRole", "UserRegions.Region", "UserSites.Site", "UserBuildings.Building" }, null, true, true);

            ICollection<UserDto> listDto = new Collection<UserDto>();
            foreach (User user in list)
                listDto.Add(MappingUserToUserDto(user));

            return listDto;
        }

        /// <summary>
        /// Method to get user roles depends on user role
        /// </summary>
        /// <returns>ICollection - UserRoleDto</returns>
        public async Task<ICollection<UserRoleDto>> GetUserRoles()
        {
            ICollection<UserRole> list;
            if (GlobalFunctions.LoggedUserRole == UserRoles.ADM)
                list = await _repoUserRole.GetAllAsync();
            else
                list = await _repoUserRole.GetByFilterAsync(c => c.Role != UserRoles.USER);

            return _mapper.Map<ICollection<UserRoleDto>>(list);
        }

        /// <summary>
        /// Method to check if exist network user duplicated
        /// </summary>
        /// <param name="userDto">UserDto</param>
        /// <returns>bool</returns>
        public async Task<bool> DuplicateExists(UserDto userDto)
        {
            if (userDto.Id == 0)
                return await _repo.ExistDataAsync(c => c.NetworkUser.ToUpper() == userDto.NetworkUser.ToUpper());
            else
                return await _repo.ExistDataAsync(c => c.Id != userDto.Id && c.NetworkUser.ToUpper() == userDto.NetworkUser.ToUpper());
        }

        /// <summary>
        /// Method to check if user exist by email
        /// </summary>
        /// <param name="email">email</param>
        /// <returns>bool</returns>
        public async Task<bool> CheckIfUserExist(string email)
        {
            return await _repo.ExistDataAsync(c => c.Active && c.Email.ToUpper() == email.ToUpper());
        }

        /// <summary>
        /// Method to active user
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> Activate(int id)
        {
            User user = await _repo.GetOneByFilterAsync(x => x.Id == id,
                new Collection<string> { "UserRole"});

            if (user == null)
                return null;

            UserDto oldUser = _mapper.Map<UserDto>(user);

            user.Active = true;
            UserDto userDto = _mapper.Map<UserDto>(user);

            await _repo.SaveAsync(user);

            return userDto;
        }

        /// <summary>
        /// Method to inactive user
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> Inactivate(int id)
        {
            User user = await _repo.GetOneByFilterAsync(x => x.Id == id,
                new Collection<string> { "UserRole"});

            if (user == null)
                return null;

            UserDto oldUser = _mapper.Map<UserDto>(user);

            user.Active = false;
            UserDto userDto = _mapper.Map<UserDto>(user);

            await _repo.SaveAsync(user);

            return userDto;
        }
    }
}
