﻿namespace FluxoCaixa.Models.Constants
{
    /// <summary>
    /// List of profiles of the system
    /// </summary>
    public static class UserRoles
    {
        /// <summary>
        /// Profile Global ADM
        /// </summary>
        public const string ADM = "ADM";
        /// <summary>
        /// Profile User
        /// </summary>
        public const string USER = "USER";
    }
}
