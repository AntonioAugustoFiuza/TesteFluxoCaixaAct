﻿namespace FluxoCaixa.Models.AbsModels
{
    /// <summary>
    /// Class Page Filter
    /// </summary>
    public class PageFilter
    {
        /// <summary>
        /// Number page
        /// </summary>
        public int pageNumber { get; set; } = 1;
        /// <summary>
        /// Size page
        /// </summary>
        public int pageSize { get; set; } = 10;
    }
}
