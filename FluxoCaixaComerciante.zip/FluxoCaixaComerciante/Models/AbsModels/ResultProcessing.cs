﻿namespace GlobalMRBTool.Models.AbsModels
{
    /// <summary>
    /// Class Result processing
    /// </summary>
    public class ResultProcessing
    {
        /// <summary>
        /// Sucesss
        /// </summary>
        public bool Success { get; set; }
        /// <summary>
        /// Message
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Additional Data
        /// </summary>
        public object AdditionalData { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public ResultProcessing()
        {
            Success = false;
            Message = "";
            AdditionalData = "";
        }
    }
}
