﻿namespace Models.AbsModels
{
    /// <summary>
    /// 
    /// </summary>
    public class ClientHost
    {
        /// <summary>
        /// 
        /// </summary>
        public string RemoteIpAddress { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ClientIpAddress { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string LocalIpAddress { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ErrorMessage { get; set; }
    }
}
