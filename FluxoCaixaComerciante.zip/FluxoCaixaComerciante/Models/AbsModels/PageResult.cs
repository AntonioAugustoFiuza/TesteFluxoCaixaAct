﻿namespace FluxoCaixa.Models.AbsModels
{
    /// <summary>
    /// Class Page Result
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PageResult<T> where T : class
    {
        /// <summary>
        /// Number Page
        /// </summary>
        public int PageNumber { get; set; }
        /// <summary>
        /// Size Page
        /// </summary>
        public int PageSize { get; set; }
        /// <summary>
        /// Count row
        /// </summary>
        public int RowCount { get; set; }
        /// <summary>
        /// List of data
        /// </summary>
        public ICollection<T> Data { get; set; }

        /// <summary>
        /// Constructor to define values of the page result
        /// </summary>
        /// <param name="page">Page</param>
        /// <param name="pageSize">Size Page</param>
        /// <param name="count">Count</param>
        /// <param name="data">Data</param>
        public PageResult(int page, int pageSize, int count, ICollection<T> data)
        {
            PageNumber = page;
            PageSize = pageSize;
            RowCount = count;
            Data = data;
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public PageResult()
        {
        }
    }
}
