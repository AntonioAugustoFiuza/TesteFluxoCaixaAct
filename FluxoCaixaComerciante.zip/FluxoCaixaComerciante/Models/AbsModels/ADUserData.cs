﻿namespace GlobalMRBTool.Models.AbsModels
{
    /// <summary>
    /// Class User Data from Active Directory 
    /// </summary>
    public class ADUserData
    {
        /// <summary>
        /// Network User
        /// </summary>
        public string NetworkUser { get; set; }
        /// <summary>
        /// Employee Number
        /// </summary>
        public string EmployeeNumber { get; set; }
        /// <summary>
        /// Full Name
        /// </summary>
        public string FullName { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Position
        /// </summary>
        public string Position { get; set; }
    }
}
