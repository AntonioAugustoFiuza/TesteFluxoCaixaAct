﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;

namespace FluxoCaixa.Models.GlobalFunction
{
    /// <summary>
    /// Class Global Functions
    /// </summary>
    public static class GlobalFunctions
    {
        /// <summary>
        /// Property Http Context Accessor
        /// </summary>
        private static IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// Property System
        /// </summary>
        public static string SystemUser => "System";

        /// <summary>
        /// Property to check if user is authenticated
        /// </summary>
        public static bool UserIsAuthenticated => (_httpContextAccessor != null) &&( _httpContextAccessor.HttpContext != null) && (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated);

        /// <summary>
        /// Property to get Logged User Name
        /// </summary>
        public static string LoggedUserName => UserIsAuthenticated ? _httpContextAccessor.HttpContext.User.Identity.Name ?? SystemUser : SystemUser;

        /// <summary>
        /// Property to get Logged User Email
        /// </summary>
        public static string LoggedUserEmail => UserIsAuthenticated ? _httpContextAccessor.HttpContext.Request.Headers["EmailUser"].ToString() : string.Empty;

        /// <summary>
        /// Property to get Logged User Role
        /// </summary>
        public static string LoggedUserRole 
        { 
            get 
            {
                string role = string.Empty;
                if (UserIsAuthenticated)
                {
                    var claim = _httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
                    if (claim != null)
                        role = claim.Value;
                }

                 return role;
            } 
        }

        /// <summary>
        /// Method to set up Http Context Accessor instance in startup app
        /// </summary>
        /// <param name="httpContextAccessor">httpContextAccessor</param>
        public static void SetHttpContextAccessor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Method to get property info
        /// </summary>
        /// <param name="classType">Class type</param>
        /// <param name="fieldName">Field name</param>
        /// <returns></returns>
        public static PropertyInfo GetPropertyModel(Type classType, string fieldName)
        {
            var property = classType.GetProperties(BindingFlags.DeclaredOnly |
                                       BindingFlags.Public |
                                       BindingFlags.Instance).
                                       FirstOrDefault(c => c.Name.Equals(fieldName, StringComparison.OrdinalIgnoreCase));

            return property;
        }

        /// <summary>
        /// Method responsible for check if directory(network) is valid
        /// </summary>
        /// <param name="path">path</param>
        /// <returns>Valid or not</returns>
        public static bool CheckUrlDirectory(string path)
        {
            bool isValid = true;

            if (!string.IsNullOrEmpty(path))
            {
                string url = path.Trim();
                string[] array = url.Split('\\').Where(c => !string.IsNullOrWhiteSpace(c)).ToArray();
                
                if (url.EndsWith("\\"))
                    isValid = false;
                else if (array.Length > 0)
                {
                    string value;
                    for (int i = 0; i < array.Length; i++)
                    {
                        value = array[i];
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            isValid = false;
                            break;
                        }
                    }
                }
            }

            return isValid;
        }

        /// <summary>
        /// Method to get id and description of the string list with separator
        /// </summary>
        /// <param name="list">list</param>
        /// <param name="separator">separator</param>
        /// <returns>List of dictionary with key = string and value = string</returns>
        public static IDictionary<string, string> GetIdDescStr(ICollection<string> list, string separator)
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            string[] split;
            string val;
            foreach (string item in list)
            {
                split = item.Split(separator);
                val = split[0];

                if (split.Length > 1 && !result.ContainsKey(val))
                    result.Add(val, split[1]);
            }

            return result;
        }

        /// <summary>
        /// Method to get id and description of the string list with separator
        /// </summary>
        /// <param name="list">list</param>
        /// <param name="separator">separator</param>
        /// <returns>List of dictionary with key = int and value = string</returns>
        public static IDictionary<int, string> GetIdDesc(ICollection<string> list, string separator)
        {
            IDictionary<int, string> result = new Dictionary<int, string>();
            string[] split;
            int valId = 0;
            foreach (string item in list)
            {
                split = item.Split(separator);

                if (split.Length > 1 && int.TryParse(split[0], out valId) && !result.ContainsKey(valId))
                    result.Add(valId, split[1]);
            }

            return result;
        }

        /// <summary>
        /// Method to check if property type is number or not
        /// </summary>
        /// <param name="classType">Class type</param>
        /// <param name="fieldName">Field name</param>
        /// <returns>True or false</returns>
        public static bool PropertyTypeIsNumber(Type classType, string fieldName)
        {
            var property = GetPropertyModel(classType, fieldName);

            switch (Type.GetTypeCode(property.PropertyType))
            {
                case TypeCode.Byte:
                case TypeCode.SByte:
                case TypeCode.UInt16:
                case TypeCode.UInt32:
                case TypeCode.UInt64:
                case TypeCode.Int16:
                case TypeCode.Int32:
                case TypeCode.Int64:
                case TypeCode.Decimal:
                case TypeCode.Double:
                case TypeCode.Single:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="classType"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static bool PropertyTypeIsString(Type classType, string fieldName)
        {
            var property = GetPropertyModel(classType, fieldName);

            switch (Type.GetTypeCode(property.PropertyType))
            {
                case TypeCode.String:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string FormatTimeSpan(TimeSpan time)
        {
            return new DateTime().Add(time).ToString("hh:mm tt", CultureInfo.CurrentUICulture);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="time"></param>
        /// <param name="format"></param>
        /// <param name="currentCulture"></param>
        /// <returns></returns>
        public static string FormatTimeSpan(TimeSpan time, string format, CultureInfo currentCulture)
        {
            return new DateTime().Add(time).ToString(format, currentCulture);
        }

        /// <summary>
        /// format date time to string
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static string FormatDateTime(DateTime dateTime)
        {
            return dateTime.ToString("MM/dd/yyyy HH:mm", CultureInfo.CurrentUICulture);
        }

        /// <summary>
        /// Method responsible for check emails and return list of recipients emails
        /// </summary>
        /// <param name="listEmail">Emails list</param>
        /// <returns>Recipients list</returns>
        public static StringBuilder CheckUsersEmail(ICollection<string> listEmail)
        {
            StringBuilder listEmails = new StringBuilder();

            List<string> validEmailsList = new List<string>();

            if (listEmail != null)
            {
                foreach (string email in listEmail.Distinct().ToList())
                {
                    if (!string.IsNullOrWhiteSpace(email) && IsValidEmail(email))
                    {
                        validEmailsList.Add(email.Trim());
                    }
                }

                if (validEmailsList.Count > 0)
                {
                    string emails = string.Join(";", validEmailsList);
                    listEmails.Append(emails);
                }
            }

            return listEmails;
        }

        /// <summary>
        /// Method responsible for check emails and return list of recipients emails
        /// </summary>
        /// <param name="listEmail">Emails list</param>
        /// <returns>Recipients list</returns>
        public static List<string> GetValidUserEmailAdresses(ICollection<string> listEmail)
        {
            List<string> validEmailsList = new List<string>();

            if (listEmail != null)
            {
                foreach (string email in listEmail.Distinct().ToList())
                {
                    if (!string.IsNullOrWhiteSpace(email) && IsValidEmail(email))
                    {
                        validEmailsList.Add(email.Trim());
                    }
                }
            }

            return validEmailsList;
        }

        /// <summary>
        /// Method responsible for check if email addres is valid or not 
        /// </summary>
        /// <param name="emailAddress">Email address</param>
        /// <returns>is valid or not</returns>
        public static bool IsValidEmail(string emailAddress)
        {
            const string validEmailPattern = @"^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$";
            var regex = new Regex(validEmailPattern, RegexOptions.IgnoreCase);
            return regex.IsMatch(emailAddress);
        }

        /// <summary>
        /// Format field value
        /// </summary>
        /// <returns>Formated value</returns>
        public static string FormatFieldValue(string fieldValue)
        {
            string formatedFieldValue = "N/A";

            if (fieldValue != null && fieldValue.Trim().Length > 0)
            {
                formatedFieldValue = fieldValue.Trim();
            }

            return formatedFieldValue;
        }

        /// <summary>
        /// Truncate decimal number
        /// </summary>
        /// <returns></returns>
        public static decimal Truncate(decimal d, byte decimals)
        {
            decimal r = Math.Round(d, decimals);

            if (d > 0 && r > d)
            {
                return r - new decimal(1, 0, 0, false, decimals);
            }
            else if (d < 0 && r < d)
            {
                return r + new decimal(1, 0, 0, false, decimals);
            }

            return r;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToDescription(this Enum value)
        {
            var da = (DescriptionAttribute[])(value.GetType().GetField(value.ToString())).GetCustomAttributes(typeof(DescriptionAttribute), false);
            return da.Length > 0 ? da[0].Description : value.ToString();
        }
        
        

        /// <summary>
        /// Method to Get Values of enum by display name
        /// </summary>
        /// <param name="enumType"></param>
        /// <param name="displayName"></param>
        /// <returns></returns>
        public static List<int> GetEnumValuesByDisplayName(Type enumType, string displayName)
        {
            List<int> enums = new();

            foreach (var enumValue in Enum.GetValues(enumType))
            {
                string enumName = enumValue.GetType().GetMember(enumValue.ToString()).First().GetCustomAttribute<DisplayAttribute>().Name;

                if (enumName.ToString().ToUpper().Contains(displayName.ToString().ToUpper()))
                {
                    enums.Add((int)Enum.Parse(enumType, enumValue.ToString()));
                }
            }

            return enums;
        }

        /// <summary>
        /// Method to get Standard DateTime
        /// </summary>
        /// <param name="dateTime">dateTime</param>
        /// <returns>Standard DateTime</returns>
        public static string GetStandardDateTimeDesc(DateTime dateTime)
        {
            string standardDateTimeToken = "";
            DateTime standardDateTime;
            string[] timezones = new string[] { "America/New_York", "Eastern Standard Time" };
            int i = 0;
            while (i < timezones.Length && string.IsNullOrEmpty(standardDateTimeToken))
            {
                try
                {
                    standardDateTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dateTime, timezones[i]);
                    standardDateTimeToken = standardDateTime.ToString("yyyy-MM-dd HH:mm:ss");
                }
                catch
                {
                    //no log needed
                }
                i++;
            }

            return standardDateTimeToken;
        }
    }
}
