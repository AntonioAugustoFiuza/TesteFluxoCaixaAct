﻿namespace FluxoCaixa.Models.Enums
{
    /// <summary>
    /// Enum Project Type
    /// </summary>
    public enum ProjectType
    {
        /// <summary>
        /// WebApi Enum Type
        /// </summary>
        WebApi,
        /// <summary>
        /// Active Directory Api Enum Type
        /// </summary>
        AdApi,
        /// <summary>
        /// JemsdiApi Enum Type
        /// </summary>
        JemsdiApi,
        /// <summary>
        /// CnfApi Enum Type
        /// </summary>
        CnfApi
    }
}
