﻿namespace GlobalMRBTool.Models.Enums
{
    /// <summary>
    /// Enum AWS Environment
    /// </summary>
    public enum AwsEnvironment
    {
        /// <summary>
        /// DEV environment
        /// </summary>
        DEV,
        /// <summary>
        /// QA environment
        /// </summary>
        QA,
        /// <summary>
        /// STG environment
        /// </summary>
        STG,
        /// <summary>
        /// PRD environment
        /// </summary>
        PRD
    }
}
