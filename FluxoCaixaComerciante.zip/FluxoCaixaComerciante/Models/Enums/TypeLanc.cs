﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FluxoCaixa.Models.Enums
{
    /// <summary>
    /// Enum TypeLanc
    /// </summary>
    public enum TypeLanc
    {
        ///<summary>Credit</summary>
        [Description("Credit")]
        [Display(Name = "Credit")]
        Credit = 0,
        ///<summary>Debit</summary>
        [Description("Debit")]
        [Display(Name = "Debit")]
        Debit
    }
}
