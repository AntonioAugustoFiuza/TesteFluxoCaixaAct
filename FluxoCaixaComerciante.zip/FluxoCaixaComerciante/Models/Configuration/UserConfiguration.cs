﻿using FluxoCaixa.Models.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FluxoCaixa.Models.Configuration
{
    /// <summary>
    /// Class "User" table configuration
    /// </summary>
    public class UserConfiguration : BaseModelConfiguration<User>
    {
        /// <summary>
        /// Method to configure the database "User" table
        /// </summary>
        /// <param name="builder">Builder</param>
        public override void Configure(EntityTypeBuilder<User> builder)
        {
            // Firstly calling base configuration
            base.Configure(builder);

            // Table Name
            builder.ToTable("Users");

            builder.Property(t => t.NetworkUser)
            .IsRequired()
            .HasMaxLength(100);

            builder.Property(t => t.EmployeeNumber)
            .HasMaxLength(100);

            builder.Property(t => t.FullName)
            .HasMaxLength(200);

            builder.Property(t => t.Email)
            .HasMaxLength(200);

            builder.Property(t => t.Position)
           .HasMaxLength(200);

            builder.Property(t => t.Active)
            .IsRequired();

            // One to many relationship
            builder.HasOne(x => x.UserRole)
            .WithMany(x => x.Users)
            .HasForeignKey(x => x.UserRoleId)
            .IsRequired()
            .OnDelete(DeleteBehavior.NoAction);

        }
    }
}

