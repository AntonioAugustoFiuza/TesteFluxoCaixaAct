﻿using FluxoCaixa.Models.Base;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FluxoCaixa.Models.Configuration.Base
{
    /// <summary>
    /// Class base model configuration
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class BaseModelConfiguration<T> : IEntityTypeConfiguration<T> where T : BaseModel
    {
        /// <summary>
        /// Method to configure the database table
        /// </summary>
        /// <param name="builder">Builder</param>
        public virtual void Configure(EntityTypeBuilder<T> builder)
        {
            // Primary Key
            builder.HasKey(t => t.Id);

            // Id Column
            builder.Property(t => t.Id)
            .HasColumnName("Id")
            .ValueGeneratedOnAdd();

            builder.Property(t => t.UserCreate)
            .IsRequired()
            .HasMaxLength(200);

            builder.Property(t => t.DateCreate)
            .IsRequired().HasDefaultValueSql("now()");

            builder.Property(t => t.UserUpdate)
            .HasMaxLength(200);

            builder.Property(t => t.DateUpdate);
        }
    }
}
