﻿using FluxoCaixa.Models.Configuration.Base;
using FluxoCaixa.Models.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FluxoCaixa.Models.Configuration
{
    /// <summary>
    /// Class "Lanc" table configuration
    /// </summary>
    public class LancConfiguration : BaseModelConfiguration<Lanc>
    {
        /// <summary>
        /// Method to configure the database "Lanc" table
        /// </summary>
        /// <param name="builder">Builder</param>
        public override void Configure(EntityTypeBuilder<Lanc> builder)
        {
            // Firstly calling base configuration
            base.Configure(builder);

            // Table Name
            builder.ToTable("Lanc");

            builder.Property(t => t.DateLanc)
            .IsRequired();

            builder.Property(t => t.TypeLanc)
            .IsRequired()
            .HasDefaultValue(TypeLanc.Credit);

            builder.Property(t => t.DescLanc)
            .HasMaxLength(200)
            .IsRequired();

            builder.Property(t => t.Value)
            .IsRequired();

        }
    }
}
