﻿using FluxoCaixa.Models.Configuration.Base;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FluxoCaixa.Models.Configuration
{
    /// <summary>
    /// Class "UserRole" table configuration
    /// </summary>
    public class UserRoleConfiguration : BaseModelConfiguration<UserRole>
    {
        /// <summary>
        /// Method to configure the database "UserRole" table
        /// </summary>
        /// <param name="builder">Builder</param>
        public override void Configure(EntityTypeBuilder<UserRole> builder)
        {
            // Firstly calling base configuration
            base.Configure(builder);

            // Table Name
            builder.ToTable("UserRoles");

            builder.HasIndex(c => new { c.Description }).IsUnique();

            builder.Property(t => t.Description)
            .IsRequired()
            .HasMaxLength(200);

            builder.Property(t => t.Role)
            .IsRequired()
            .HasMaxLength(20);
        }
    }
}

