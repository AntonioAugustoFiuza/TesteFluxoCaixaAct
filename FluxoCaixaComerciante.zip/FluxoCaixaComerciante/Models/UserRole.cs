using FluxoCaixa.Models.Base;
using System.Collections.Generic;

namespace FluxoCaixa.Models
{
    /// <summary>
    /// Class "User Role" model
    /// </summary>
    public class UserRole : BaseModel
    {
        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Role
        /// </summary>
        public string Role { get; set; }
        /// <summary>
        /// List of Users
        /// </summary>
        public ICollection<User> Users { get; set; }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public UserRole()
        {
            Users = new HashSet<User>();
        }
    }
}