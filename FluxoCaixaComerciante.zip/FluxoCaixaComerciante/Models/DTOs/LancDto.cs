﻿using FluxoCaixa.Models.DTOs.Base;
using FluxoCaixa.Models.Enums;
using System.ComponentModel.DataAnnotations;

namespace FluxoCaixa.Models.DTOs
{
    /// <summary>
    /// Dto to lanc entity
    /// </summary>
    public class LancDto : BaseDto
    {
        /// <summary>
        /// Date Lanc
        /// </summary>
        [Required]
        public DateTime DateLanc { get; set; }

        /// <summary>
        /// Site id
        /// </summary>
        [Required]
        public TypeLanc TypeLanc { get; set; }
        /// <summary>
        /// Description Lanc
        /// </summary>
        [Required]
        public string DescLanc { get; set; }
        /// <summary>
        /// Value of the lanc
        /// </summary>
        [Required]
        public string Value { get; set; }
    }
}
