﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace FluxoCaixa.Models.DTOs
{
    /// <summary>
    /// Class User DTO
    /// </summary>
    public class UserNameDto
    {
        /// <summary>
        /// Network User
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Networkuser
        /// </summary>
        [JsonIgnore]
        public string NetworkUser { get; set; }
        /// <summary>
        /// Full name
        /// </summary>
        [JsonIgnore]
        public string FullName { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        [JsonIgnore]
        public string Email { get; set; }
        /// <summary>
        /// Networkuser - Full name
        /// </summary>
        [Required]
        public string Description 
        { 
            get
            {
                return NetworkUser + " - " + FullName;
            }
        
        }
    }
}
