﻿using System.ComponentModel.DataAnnotations;

namespace FluxoCaixa.Models.DTOs
{
    /// <summary>
    /// Dto to user filter validation
    /// </summary>
    public class UserFilterDto
    {
        /// <summary>
        /// 
        /// </summary>
        [Required]
        public string Networkuser { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Id { get; set; }
    }
}
