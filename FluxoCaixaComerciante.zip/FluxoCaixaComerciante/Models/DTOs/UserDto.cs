﻿using FluxoCaixa.Models.DTOs.Base;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FluxoCaixa.Models.DTOs
{
    /// <summary>
    /// Class User DTO
    /// </summary>
    public class UserDto : BaseDto
    {
        /// <summary>
        /// Network User
        /// </summary>
        [Required]
        public string NetworkUser { get; set; }
        /// <summary>
        /// Employee Number
        /// </summary>
        public string EmployeeNumber { get; set; }
        /// <summary>
        /// Full Name
        /// </summary>
        public string FullName { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Position
        /// </summary>
        public string Position { get; set; }
        /// <summary>
        /// Is Active?
        /// </summary>
        [Required]
        public bool Active { get; set; }

        /// <summary>
        /// Description active
        /// </summary>
        public string ActiveDesc { get; set; }
        /// <summary>
        /// User Role Id
        /// </summary>
        [Required]
        public int UserRoleId { get; set; }
        /// <summary>
        /// User Role Description
        /// </summary>
        public string UserRoleDesc { get; set; }

        /// <summary>
        /// User that created
        /// </summary>
        public override string UserCreate { get; set; }

        /// <summary>
        /// Last User that updated
        /// </summary>
        public override string UserUpdate { get; set; }

        /// <summary>
        /// Date and Time that was created
        /// </summary>
        public override DateTime DateCreate { get; set; }

        /// <summary>
        /// Last Date and Time that was updated
        /// </summary>
        public override DateTime? DateUpdate { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public UserDto()
        {
        }
    }
}
