﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using FluxoCaixa.Models.GlobalFunction;

namespace FluxoCaixa.Models.DTOs.Base
{
    /// <summary>
    /// Class base DTO
    /// </summary>
    public class BaseDto
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// User name created
        /// </summary>
        public virtual string UserCreate { get; set; }
        /// <summary>
        /// Date and time created
        /// </summary>
        public virtual DateTime DateCreate { get; set; }
        /// <summary>
        /// User name Updated
        /// </summary>
        public virtual string UserUpdate { get; set; }
        /// <summary>
        /// Data and time updated
        /// </summary>
        public virtual DateTime? DateUpdate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public BaseDto()
        {
            this.UserCreate = GlobalFunctions.LoggedUserName;
        }
    }
}
