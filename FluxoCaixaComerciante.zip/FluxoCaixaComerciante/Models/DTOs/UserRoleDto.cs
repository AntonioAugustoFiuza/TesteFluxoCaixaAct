﻿using FluxoCaixa.Models.DTOs.Base;

namespace FluxoCaixa.Models.DTOs
{
    /// <summary>
    /// 
    /// </summary>
    public class UserRoleDto : BaseDto
    {
        /// <summary>
        /// 
        /// </summary>
        public string Description { get; set; }
    }
}
