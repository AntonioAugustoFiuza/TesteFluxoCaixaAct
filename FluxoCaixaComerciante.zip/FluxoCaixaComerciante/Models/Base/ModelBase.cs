using FluxoCaixa.Models.Base.Interface;
using FluxoCaixa.Models.GlobalFunction;
using System.ComponentModel.DataAnnotations.Schema;

namespace FluxoCaixa.Models.Base
{
    /// <summary>
    /// Class Base model
    /// </summary>
    public class BaseModel : IBaseModel
    {
        /// <summary>
        /// Id - Auto Increment
        /// </summary>
        [Column(Order = 0)]
        public int Id { get; set; }
        /// <summary>
        /// User name Created
        /// </summary>
        public string UserCreate { get; set; }
        /// <summary>
        /// Date and Time Created
        /// </summary>
        public DateTime DateCreate { get; set; }
        /// <summary>
        /// User name Updated
        /// </summary>
        public string UserUpdate { get; set; }
        /// <summary>
        /// Date and Time Updated
        /// </summary>
        public DateTime? DateUpdate { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public BaseModel()
        {
            DateCreate = DateTime.Now;
            UserCreate = GlobalFunctions.LoggedUserName;
        }
    }
}
