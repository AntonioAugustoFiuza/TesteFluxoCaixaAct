﻿using System;

namespace FluxoCaixa.Models.Base.Interface
{
    /// <summary>
    /// Interface Base Model
    /// </summary>
    public interface IBaseModel
    {
        /// <summary>
        /// Id
        /// </summary>
        int Id { get; set; }
        /// <summary>
        /// User name Created
        /// </summary>
        string UserCreate { get; set; }
        /// <summary>
        /// Date and Time Created
        /// </summary>
        DateTime DateCreate { get; set; }
        /// <summary>
        /// USer Name Updated
        /// </summary>
        string UserUpdate { get; set; }
        /// <summary>
        /// Date and Time Updated
        /// </summary>
        DateTime? DateUpdate { get; set; }
    }
}
