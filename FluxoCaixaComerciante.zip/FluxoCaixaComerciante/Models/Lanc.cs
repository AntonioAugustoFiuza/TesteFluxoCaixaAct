using FluxoCaixa.Models.Base;
using FluxoCaixa.Models.Enums;

namespace FluxoCaixa.Models
{
    /// <summary>
    /// MeetingPresence Model
    /// </summary>
    public class Lanc : BaseModel
    {
        /// <summary>
        /// Date of Lanc
        /// </summary>
        public DateTime DateLanc { get; set; }
        /// <summary>
        /// Type Lanc
        /// </summary>
        public TypeLanc TypeLanc { get; set; }

        /// <summary>
        /// Lanc description
        /// </summary>
        public string DescLanc { get; set; }

        /// <summary>
        /// Value
        /// </summary>
        public decimal Value { get; set; }
    }
}
