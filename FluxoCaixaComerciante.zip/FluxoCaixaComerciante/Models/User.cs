using FluxoCaixa.Models.Base;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;

namespace FluxoCaixa.Models
{
    /// <summary>
    /// Class "User" model
    /// </summary>
    public class User : BaseModel
    {
        /// <summary>
        /// Network User
        /// </summary>
        public string NetworkUser { get; set; }
        /// <summary>
        /// Employee Number
        /// </summary>
        public string EmployeeNumber { get; set; }
        /// <summary>
        /// Full Name
        /// </summary>
        public string FullName { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Position
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// Is Active?
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// User Role Model
        /// </summary>
        [ForeignKey("UserRoleId")]
        public UserRole UserRole { get; set; }
        /// <summary>
        /// User Role Id
        /// </summary>
        public int UserRoleId { get; set; }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public User()
        {
        }
    }
}