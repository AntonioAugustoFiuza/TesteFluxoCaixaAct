using FluxoCaixa.Models.AbsModels;
using System.Linq.Expressions;

namespace FluxoCaixa.Interfaces.Base
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IRepository<T> where T : class
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="forceCreate"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task SaveAsync(T entity, bool forceCreate = false, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="listEntity"></param>
        /// <param name="forceCreate"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task SaveRangeAsync(ICollection<T> listEntity, bool forceCreate = false, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="property"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task UpdateAsync(T entity, Expression<Func<T, object>> property, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task AddAsync(T entity, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task EditAsync(T entity, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="listEntity"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task EditRangeAsync(ICollection<T> listEntity, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="listEntity"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task RemoveRangeAsync(ICollection<T> listEntity, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="id"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task DeleteAsync(T entity, int id, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="listEntity"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task DeleteRangeAsync(ICollection<T> listEntity, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        void UnchangedEntity(T entity);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        void Attach(T entity);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task ReloadAsync(T entity, CancellationToken cancellationToken = default);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<T> GetByIdAsync(int id);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="predicate"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        Task<T> FirstAsync(Expression<Func<T, bool>> predicate = null, ICollection<string> includes = null);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="includes"></param>
        /// <param name="orderingFunction"></param>
        /// <param name="orderingAsc"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<ICollection<T>> GetByFilterAsync(
            Expression<Func<T, bool>> filter,
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="includes"></param>
        /// <param name="orderingFunction"></param>
        /// <param name="orderingAsc"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<T> GetOneByFilterAsync(
            Expression<Func<T, bool>> filter,
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="includes"></param>
        /// <param name="orderingFunction"></param>
        /// <param name="orderingAsc"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<ICollection<T>> GetAllAsync(
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="includes"></param>
        /// <param name="orderingFunction"></param>
        /// <param name="orderingAsc"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageLength"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<PageResult<T>> GetAllPagedAsync(
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            int pageNumber = 0,
            int pageLength = -1,
            bool asNoTracking = true);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageLength"></param>
        /// <param name="orderingFunction"></param>
        /// <param name="orderingAsc"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<PageResult<T>> GetListPagedAsync(
            IQueryable<T> query,
            int pageNumber = 0,
            int pageLength = -1,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true
            );
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="skip"></param>
        /// <param name="pageLength"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<ICollection<T>> GetListPagedResultAsync(
            IQueryable<T> query,
            int skip = 0,
            int pageLength = -1,
            bool asNoTracking = true
            );
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageFilter"></param>
        /// <param name="filterList"></param>
        /// <param name="filter"></param>
        /// <param name="includes"></param>
        /// <param name="orderingFunction"></param>
        /// <param name="orderingAsc"></param>
        /// <param name="asNoTracking"></param>
        /// <returns></returns>
        Task<PageResult<T>> GetByFilterPaginationAsync(
            PageFilter pageFilter,
            ICollection<string> filterList,
            ICollection<string> filter,
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        Task<int> CountAsync(Expression<Func<T, bool>> filter = null);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        Task<bool> ExistDataAsync(Expression<Func<T, bool>> filter);
    }
}