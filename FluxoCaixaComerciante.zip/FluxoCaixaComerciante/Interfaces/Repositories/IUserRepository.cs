﻿using FluxoCaixa.Interfaces.Base;
using FluxoCaixa.Models;
using FluxoCaixa.Models.DTOs;

namespace FluxoCaixa.Interfaces.Repositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IUserRepository : IRepository<User>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userFilterDto"></param>
        /// <returns></returns>
        Task<bool> CheckIfExist(UserFilterDto userFilterDto);


        /// <summary>
        /// Get User by filters
        /// </summary>
        /// <param name="userFilterDto"></param>
        /// <returns></returns>
        Task<UserDto> GetUserByNetworkAndFilters(UserFilterDto userFilterDto);

        /// <summary>
        /// Get user dto by id to info
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Task<UserDto> GetUserInfoById(int userId);
    }
}