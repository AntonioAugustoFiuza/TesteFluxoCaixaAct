﻿using FluxoCaixa.Models;
using FluxoCaixa.Interfaces.Base;

namespace FluxoCaixa.Interfaces.Repositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IUserRoleRepository : IRepository<UserRole>
    {
    }
}

