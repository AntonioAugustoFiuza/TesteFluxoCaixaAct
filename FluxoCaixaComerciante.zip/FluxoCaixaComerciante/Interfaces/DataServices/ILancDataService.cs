﻿using FluxoCaixa.Models.AbsModels;
using FluxoCaixa.Models.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FluxoCaixa.Interfaces.DataServices
{
    /// <summary>
    /// 
    /// </summary>
    public interface ILancDataService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<LancDto> Get(int id);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lancDto"></param>
        /// <returns></returns>
        Task<LancDto> Add(LancDto lancDto);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lancDto"></param>
        /// <returns></returns>
        Task<LancDto> Update(LancDto lancDto);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Task<ICollection<LancDto>> List();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Task<ICollection<LancDto>> ListConsolated(DateTime date);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lancDto"></param>
        /// <returns></returns>
        Task<bool> DuplicateExists(LancDto lancDto);
    }
}
