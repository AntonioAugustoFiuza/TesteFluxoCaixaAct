﻿using FluxoCaixa.Models.AbsModels;
using FluxoCaixa.Models.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FluxoCaixa.Interfaces.DataServices
{
    /// <summary>
    /// 
    /// </summary>
    public interface IUserDataService
    {
        /// <summary>
        /// Get user dto by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<UserDto> GetById(int id);
        /// <summary>
        /// Get user dto by id to info
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<UserDto> GetUserInfoById(int id);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="networkUser"></param>
        /// <returns></returns>
        Task<UserDto> GetByNetworkUser(string networkUser);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        Task<UserDto> GetUserByEmail(string email);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userFilterDto"></param>
        /// <returns></returns>
        Task<bool> CheckIfExist(UserFilterDto userFilterDto);
        /// <summary>
        /// Asynchronous method to get Users by filters
        /// </summary>
        /// <param name="userFilterDto"></param>
        /// <returns></returns>
        Task<UserDto> GetUserByNetworkAndFilters(UserFilterDto userFilterDto);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userDto"></param>
        /// <returns></returns>
        Task<UserDto> Add(UserDto userDto);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userDto"></param>
        /// <returns></returns>
        Task<UserDto> Update(UserDto userDto);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<UserDto> Activate(int id);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<UserDto> Inactivate(int id);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Task<ICollection<UserDto>> List();
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Task<ICollection<UserRoleDto>> GetUserRoles();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userDto"></param>
        /// <returns></returns>
        Task<bool> DuplicateExists(UserDto userDto);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        Task<bool> CheckIfUserExist(string email);
    }
}
