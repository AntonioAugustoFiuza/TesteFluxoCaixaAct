﻿using FluxoCaixa.DataAccess.Repository;
using FluxoCaixa.DataAcess.Context;
using FluxoCaixa.DataServices;
using FluxoCaixa.Interfaces.DataServices;
using FluxoCaixa.Interfaces.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Security.Principal;

namespace FluxoCaixa.DI
{
    /// <summary>
    /// Class to mapping dependency injection from the system
    /// </summary>
    public static class DependencyInjection
    {
        /// <summary>
        /// Method to add services in the dependency injection container
        /// </summary>
        /// <param name="services">List of services</param> 
        /// <param name="configuration">Configuration service</param>
        /// <returns>List of the services</returns>
        public static IServiceCollection ConfigureData(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = string.Empty;
            connectionString = GetConnectionString(configuration);

            services.AddDbContext<SystemContext>(options => options.UseNpgsql(connectionString)
            .EnableSensitiveDataLogging(true).UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

            services.AddHttpContextAccessor();
            services.AddTransient<IPrincipal>(provider => provider.GetService<IHttpContextAccessor>().HttpContext.User);

            // Repositories
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserRoleRepository, UserRoleRepository>();
            services.AddScoped<ILancRepository, LancRepository>();

            // Data Services
            services.AddScoped<IUserDataService, UserDataService>();
            services.AddScoped<ILancDataService, LancDataService>();

            return services;
        }

        /// <summary>
        /// Method to define string connection in AWS RDS Postgres
        /// </summary>
        /// <param name="configuration">Configuration service</param>
        /// <returns></returns>
        private static string GetConnectionString(IConfiguration configuration)
        {
            string dbHost = configuration["db_host"];
            string dbPort = configuration["db_port"];
            string dbName = configuration["db_name"];
            string dbUserName = configuration["db_username"];
            string dbPassword = configuration["db_password"];
            
            return $"Host={dbHost};Port={dbPort};Database={dbName};Username={dbUserName};Password={dbPassword};";
        }
    }
}
