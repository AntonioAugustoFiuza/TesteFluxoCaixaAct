﻿using AutoMapper;
using FluxoCaixa.Models.DTOs;
using FluxoCaixa.Models;

namespace FluxoCaixa.DI.Mapping
{
    /// <summary>
    /// Class to mapping model and DTOs
    /// </summary>
    public class AutoMapping : Profile
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AutoMapping()
        {
            //Mapper Entity <-> DataTransferObject
            CreateMap<User, UserDto>()
                .ForMember(dest => dest.UserRoleDesc,
                opts => opts.MapFrom(src => src.UserRole.Description));

            CreateMap<UserDto, User>();


            //Mapper Entity <-> DTO

            CreateMap<UserRole, UserRoleDto>()
                .ForMember(dest => dest.Id,
                    opts => opts.MapFrom(src => src.Id))
                .ForMember(dest => dest.Description,
                    opts => opts.MapFrom(src => src.Description)).ReverseMap();

            CreateMap<Lanc, LancDto>().ReverseMap();

        }
    }
}