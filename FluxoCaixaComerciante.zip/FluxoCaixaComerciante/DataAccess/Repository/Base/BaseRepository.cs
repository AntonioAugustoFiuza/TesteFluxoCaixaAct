using FluxoCaixa.DataAcess.Context;
using FluxoCaixa.Models.AbsModels;
using FluxoCaixa.Models.Base.Interface;
using FluxoCaixa.Models.GlobalFunction;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;

namespace FluxoCaixa.DataAccess.Repository.Base
{
    /// <summary>
    /// Class base repository that contains all generic methods of the context
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class BaseRepository<T> where T : class, IBaseModel
    {
        private readonly SystemContext _context;

        /// <summary>
        /// Constructor of the class with instance of the context
        /// </summary>
        /// <param name="context">Context</param>
        protected BaseRepository(SystemContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Asynchronous method to save entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <param name="forceCreate">Is it Force Create entity?</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public async virtual Task SaveAsync(T entity, bool forceCreate = false, CancellationToken cancellationToken = default)
        {
            var newId = entity.Id;
            //New record
            if (newId == 0 || forceCreate)
            {
                if (string.IsNullOrWhiteSpace(entity.UserCreate))
                    entity.UserCreate = GlobalFunctions.LoggedUserName;

                entity.DateCreate = DateTime.Now;

                await AddAsync(entity, cancellationToken);
            }
            else //Update record
            {
                var oldEntity = await GetOneByFilterAsync(c => c.Id == newId, null, null, true, true);

                if (oldEntity != null)
                {
                    entity.UserCreate = oldEntity.UserCreate;

                    entity.DateCreate = oldEntity.DateCreate;

                    entity.UserUpdate = GlobalFunctions.LoggedUserName;
                }

                if (string.IsNullOrWhiteSpace(entity.UserUpdate))
                    entity.UserUpdate = GlobalFunctions.LoggedUserName;

                entity.DateUpdate = DateTime.Now;

                await EditAsync(entity, cancellationToken);
            }
        }

        /// <summary>
        /// Asynchronous method to save a list of entities in the context
        /// </summary>
        /// <param name="listEntity">Lit of entities</param>
        /// <param name="forceCreate">Is it Force Create entity?</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task SaveRangeAsync(ICollection<T> listEntity, bool forceCreate = false, CancellationToken cancellationToken = default)
        {
            await Task.Run(async () =>
            {
                foreach (T entity in listEntity)
                    await SaveAsync(entity, forceCreate, cancellationToken);
            }, cancellationToken);
        }

        /// <summary>
        /// Asynchronous method to update entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <param name="property">Property of the entity</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task UpdateAsync(T entity, Expression<Func<T, object>> property, CancellationToken cancellationToken = default)
        {
            await Task.Run(() =>
            {
                _context.Entry(entity).Property(property).IsModified = true;
            }, cancellationToken);
        }

        /// <summary>
        /// Asynchronous method to add entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task AddAsync(T entity, CancellationToken cancellationToken = default)
        {
            await _context.Set<T>().AddAsync(entity, cancellationToken);
        }

        /// <summary>
        /// Asynchronous method to edit entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task EditAsync(T entity, CancellationToken cancellationToken = default)
        {
            await Task.Run(() =>
            {
                _context.Entry(entity).State = EntityState.Modified;
            }, cancellationToken);
        }

        /// <summary>
        /// Asynchronous method to edit a list of entities in the context
        /// </summary>
        /// <param name="listEntity">Lit of entities</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public async virtual Task EditRangeAsync(ICollection<T> listEntity, CancellationToken cancellationToken = default)
        {
            await Task.Run(async () =>
            {
                foreach (T item in listEntity)
                    await EditAsync(item, cancellationToken);
            });
        }

        /// <summary>
        /// Asynchronous method to remove a list of entities in the context
        /// </summary>
        /// <param name="listEntity">Lit of entities</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task RemoveRangeAsync(ICollection<T> listEntity, CancellationToken cancellationToken = default)
        {
            await Task.Run(() =>
            {
                _context.Set<T>().RemoveRange(listEntity);
            }, cancellationToken);
        }

        /// <summary>
        /// Synchronous method to delete a list of entities in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <param name="id">Id of the entity</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task DeleteAsync(T entity, int id, CancellationToken cancellationToken = default)
        {
            await Task.Run(async () =>
            {
                T entityBase = entity;
                if (entityBase == null)
                    entityBase = await GetByIdAsync(id);

                if (entityBase != null)
                {
                    _context.Entry(entityBase).State = EntityState.Deleted;
                }
            }, cancellationToken);
        }

        /// <summary>
        /// Asynchronous method to delete a list of entities in the context
        /// </summary>
        /// <param name="listEntity">Lit of entities</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task DeleteRangeAsync(ICollection<T> listEntity, CancellationToken cancellationToken = default)
        {
            await Task.Run(async () =>
            {
                foreach (T entity in listEntity)
                    await DeleteAsync(entity, entity.Id, cancellationToken);
            }, cancellationToken);
        }

        /// <summary>
        /// Synchronous method to set to unchanged an entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        public virtual void UnchangedEntity(T entity)
        {
            _context.Entry(entity).State = EntityState.Unchanged;
        }

        /// <summary>
        /// Synchronous method to attach an entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        public virtual void Attach(T entity)
        {
            _context.Set<T>().Attach(entity);
        }

        /// <summary>
        /// Asynchronous method to reload an entity in the context
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns>Task</returns>
        public virtual async Task ReloadAsync(T entity, CancellationToken cancellationToken = default)
        {
            await _context.Entry(entity).ReloadAsync(cancellationToken);
        }

        /// <summary>
        /// Asynchronous method to get a record of an entity in the context by id
        /// </summary>
        /// <param name="Id">Id of the entity</param>
        /// <returns>Task of the entity</returns>
        public virtual async Task<T> GetByIdAsync(int Id)
        {
            return await _context.Set<T>().FindAsync(Id);
        }

        /// <summary>
        /// Asynchronous method to get a first record of an entity in the context
        /// </summary>
        /// <param name="predicate">Expression with the filters of the entity</param>
        /// <param name="includes">List of the relationship tables</param>
        /// <returns>Task with the entity</returns>
        public async Task<T> FirstAsync(Expression<Func<T, bool>> predicate = null, ICollection<string> includes = null)
        {
            var query = _context.Set<T>().AsQueryable();

            if (includes != null && includes.Any())
                foreach (string include in includes)
                {
                    query = query.Include(include);
                }

            if (predicate == null)
                return await query.FirstOrDefaultAsync();
            else
                return await query.FirstOrDefaultAsync(predicate);
        }

        /// <summary>
        /// Asynchronous method to get list of records of an entity in the context by filters
        /// </summary>
        /// <param name="filter">Expression with the filters of the entity</param>
        /// <param name="includes">List of the relationship tables</param>
        /// <param name="orderingFunction">Expression with the sorting of the entity</param>
        /// <param name="orderingAsc">Is it sorting ascending?</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>Task with a list of records of an entity</returns>
        public virtual async Task<ICollection<T>> GetByFilterAsync(
            Expression<Func<T, bool>> filter,
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true)
        {
            IQueryable<T> query = _context.Set<T>().Where(filter).AsQueryable();

            if (includes != null && includes.Any())
                foreach (string include in includes)
                {
                    query = query.Include(include);
                }

            if (orderingFunction != null)
            {
                if (orderingAsc)
                    query = query.OrderBy(orderingFunction).AsQueryable();
                else
                    query = query.OrderByDescending(orderingFunction).AsQueryable();
            }

            if (asNoTracking)
                return await query.AsNoTracking().ToListAsync();
            else
                return await query.ToListAsync();
        }

        /// <summary>
        /// Asynchronous method to get list of records of an entity in the context by filters
        /// </summary>
        /// <param name="filter">Expression with the filters of the entity</param>
        /// <param name="includes">List of the relationship tables</param>
        /// <param name="orderingFunction">Expression with the sorting of the entity</param>
        /// <param name="orderingAsc">Is it sorting ascending?</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>Task with a list of records of an entity</returns>
        public virtual async Task<T> GetOneByFilterAsync(
            Expression<Func<T, bool>> filter,
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true)
        {
            IQueryable<T> query = _context.Set<T>().Where(filter).AsQueryable();

            if (includes != null && includes.Any())
                foreach (string include in includes)
                {
                    query = query.Include(include);
                }

            if (orderingFunction != null)
            {
                if (orderingAsc)
                    query = query.OrderBy(orderingFunction).AsQueryable();
                else
                    query = query.OrderByDescending(orderingFunction).AsQueryable();
            }

            if (asNoTracking)
                return await query.AsNoTracking().FirstOrDefaultAsync();
            else
                return await query.FirstOrDefaultAsync();
        }

        /// <summary>
        /// Asynchronous method to get all records of an entity in the context by filters
        /// </summary>
        /// <param name="includes">List of the relationship tables</param>
        /// <param name="orderingFunction">Expression with the sorting of the entity</param>
        /// <param name="orderingAsc">Is it sorting ascending?</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>Task with a list of records of an entity</returns>
        public virtual async Task<ICollection<T>> GetAllAsync(
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true)
        {
            IQueryable<T> query = _context.Set<T>().AsQueryable();

            if (includes != null && includes.Any())
                foreach (string include in includes)
                {
                    query = query.Include(include);
                }

            if (orderingFunction != null)
            {
                if (orderingAsc)
                    query = query.OrderBy(orderingFunction).AsQueryable();
                else
                    query = query.OrderByDescending(orderingFunction).AsQueryable();
            }

            if (asNoTracking)
                return await query.AsNoTracking().ToListAsync();
            else
                return await query.ToListAsync();
        }

        /// <summary>
        /// Asynchronous method to get all records of a entity with pagination and set in the properties of the datatable
        /// </summary>
        /// <param name="includes">List of the relationship tables</param>
        /// <param name="orderingFunction">Expression with the sorting of the entity</param>
        /// <param name="orderingAsc">Is it sorting ascending?</param>
        /// <param name="pageNumber">Number of the page to calculate the amount of records to skip</param>
        /// <param name="pageLength">Amount of records to get</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>Task with a properties of the datatable and a list of records of an entity</returns>
        public virtual async Task<PageResult<T>> GetAllPagedAsync(
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            int pageNumber = 0,
            int pageLength = -1,
            bool asNoTracking = true)

        {
            IQueryable<T> query = _context.Set<T>().AsQueryable();

            if (includes != null && includes.Any())
                foreach (string include in includes)
                {
                    query = query.Include(include);
                }

            var result = await GetListPagedAsync(query, pageNumber, pageLength, orderingFunction, orderingAsc, asNoTracking);


            return result;
        }

        /// <summary>
        /// Synchronous method to get records of an entity with pagination in the context
        /// </summary>
        /// <param name="query">Query</param>
        /// <param name="skip">Amount of records to skip</param>
        /// <param name="pageLength">Amount of records to get</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>List of records of an entity with pagination</returns>
        public virtual async Task<ICollection<T>> GetListPagedResultAsync(
            IQueryable<T> query,
            int skip = 0,
            int pageLength = -1,
            bool asNoTracking = true
            )
        {
            query = query.Skip(skip);

            if (pageLength > -1)
                query = query.Take(pageLength);

            if (asNoTracking)
                return await query.AsNoTracking().ToListAsync();
            else
                return await query.ToListAsync();
        }

        /// <summary>
        /// Asynchronous method to get records of an entity with pagination in the context
        /// </summary>
        /// <param name="query">Query</param>
        /// <param name="pageNumber">Number of the page to calculate the amount of records to skip</param>
        /// <param name="pageLength">Amount of records to get</param>
        /// <param name="orderingFunction">Expression with the sorting of the entity</param>
        /// <param name="orderingAsc">Is it sorting ascending?</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>Task with a list of records of an entity with pagination</returns>
        public virtual async Task<PageResult<T>> GetListPagedAsync(
            IQueryable<T> query,
            int pageNumber = 0,
            int pageLength = -1,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true
            )
        {
            if (orderingFunction != null)
            {
                if (orderingAsc)
                    query = query.OrderBy(orderingFunction).AsQueryable();
                else
                    query = query.OrderByDescending(orderingFunction).AsQueryable();
            }

            int skip = (pageNumber - 1) * pageLength;
            int count = query.Count();
            query = query.Skip(skip);

            if (pageLength > -1)
                query = query.Take(pageLength);

            _ = new Collection<T>();
            ICollection<T> result;
            if (asNoTracking)
                result = await Task.FromResult(query.AsNoTracking().ToList());
            else
                result = await Task.FromResult(query.ToList());

            return new PageResult<T>(
                pageNumber,
                pageLength,
                count,
                result.ToList());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageFilter"></param>
        /// <param name="filterList"></param>
        /// <param name="filter">Expression with the filters of the entity</param>
        /// <param name="includes"></param>
        /// <param name="orderingFunction">Expression with the sorting of the entity</param>
        /// <param name="orderingAsc">Is it sorting ascending?</param>
        /// <param name="asNoTracking">Is it no tracking entity?</param>
        /// <returns>Task wit a properties of the datatable and a list of records of an entity</returns>
        public virtual async Task<PageResult<T>> GetByFilterPaginationAsync(
            PageFilter pageFilter,
            ICollection<string> filterList,
            ICollection<string> filter,
            ICollection<string> includes = null,
            Func<T, object> orderingFunction = null,
            bool orderingAsc = true,
            bool asNoTracking = true)
        {
            IQueryable<T> query = _context.Set<T>();

            if (includes != null && includes.Any())
            {
                foreach (string include in includes)
                {
                    query = query.Include(include);
                }
            }

            ICollection<string> predicates = new Collection<string>();
            object[] args = filter.ToArray<object>();
            string lambda = string.Empty, columnName = string.Empty, predicate = string.Empty,
            valueFilter = string.Empty;
            for (int i = 0; i < filterList.Count; i++)
            {
                lambda = filterList.ElementAt(i).ToString();
                columnName = lambda.Substring(lambda.IndexOf('.') + 1);
                valueFilter = args[i].ToString().ToUpper();
                if (GlobalFunctions.PropertyTypeIsString(typeof(T), columnName))
                    predicate = string.Format("({0} != null && {0}.ToUpper().Contains(@" + i.ToString() + "))", columnName);
                else
                    predicate = string.Format("({0} != null && {0} == (@" + i.ToString() + "))", columnName);

                predicates.Add(predicate);
                args[i] = valueFilter;
            }

            string filterString = string.Join("&&", predicates);
            query = query.Where(filterString, args);

            PageResult<T> result = await GetListPagedAsync(query, pageFilter.pageNumber, pageFilter.pageSize,
                orderingFunction, orderingAsc, asNoTracking);

            return result;
        }

        /// <summary>
        /// Asynchronous method to get count of records of an entity in the context by filters
        /// </summary>
        /// <param name="filter">Expression with the filters of the entity</param>
        /// <returns>Total of records</returns>
        public virtual async Task<int> CountAsync(Expression<Func<T, bool>> filter = null)
        {
            IQueryable<T> query = _context.Set<T>().AsQueryable();

            if (filter != null)
                return await query.AsNoTracking().Where(filter).CountAsync();
            else
                return await query.AsNoTracking().CountAsync();
        }

        /// <summary>
        /// Asynchronous method to check if records exist of an entity in the context by filters
        /// </summary>
        /// <param name="filter">Expression with the filters of the entity</param>
        /// <returns>Exist or not exist</returns>
        public virtual async Task<bool> ExistDataAsync(Expression<Func<T, bool>> filter)
        {
            IQueryable<T> query = _context.Set<T>().AsQueryable();

            if (filter != null)
                return await query.AsNoTracking().AnyAsync(filter);
            else
                return await query.AsNoTracking().AnyAsync();
        }
    }
}
