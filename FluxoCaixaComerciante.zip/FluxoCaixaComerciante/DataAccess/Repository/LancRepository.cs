﻿using FluxoCaixa.DataAccess.Repository.Base;
using FluxoCaixa.DataAcess.Context;
using FluxoCaixa.Interfaces.Repositories;
using FluxoCaixa.Models;

namespace FluxoCaixa.DataAccess.Repository
{
    /// <summary>
    /// Class user role repository
    /// </summary>
    public class LancRepository : BaseRepository<Lanc>, ILancRepository
    {
        /// <summary>
        /// Constructor of the class with instance of the context
        /// </summary>
        /// <param name="context">Context</param>
        public LancRepository(SystemContext context) : base(context)
        {
        }
    }
}
