﻿using DevExpress.Data.ODataLinq.Helpers;
using FluxoCaixa.DataAccess.Repository.Base;
using FluxoCaixa.DataAcess.Context;
using FluxoCaixa.Interfaces.Repositories;
using FluxoCaixa.Models;
using FluxoCaixa.Models.AbsModels;
using FluxoCaixa.Models.DTOs;
using FluxoCaixa.Models.GlobalFunction;
using Microsoft.EntityFrameworkCore;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;

namespace FluxoCaixa.DataAccess.Repository
{
    /// <summary>
    /// Class user repository
    /// </summary>
    public class UserRepository : BaseRepository<User>, IUserRepository
    {
        private readonly SystemContext _context;

        /// <summary>
        /// Constructor of the class with instance of the context
        /// </summary>
        /// <param name="context">Context</param>
        public UserRepository(SystemContext context) : base(context)
        {
            _context = context;
        }

        /// <summary>
        /// Get query of user dto
        /// </summary>
        /// <returns>UserDto</returns>
        private IQueryable<UserDto> GetQueryUserDto()
        {
            return (from TblUser in _context.Users.AsNoTracking().ToList()

                    join TblRole in _context.UserRoles.AsNoTracking().ToList()
                      on TblUser.UserRoleId equals TblRole.Id
                    select new UserDto()
                    {
                        Id = TblUser.Id,
                        EmployeeNumber = TblUser.EmployeeNumber,
                        FullName = TblUser.FullName,
                        NetworkUser = TblUser.NetworkUser,
                        Email = TblUser.Email,
                        Position = TblUser.Position,
                        UserRoleId = TblUser.UserRoleId,
                        UserRoleDesc = TblRole.Description,
                        Active = TblUser.Active,
                        ActiveDesc = TblUser.Active ? "Active" : "Inactive",
                    }
             ).AsQueryable();
        }

        /// <summary>
        /// Make query filter
        /// </summary>
        /// <param name="query">query</param>
        /// <param name="columnFilters">columnFilters</param>
        /// <param name="valuesFilter">valuesFilter</param>
        /// <returns></returns>
        private static IQueryable<UserDto> MakeFilterQuery(
            IQueryable<UserDto> query,
            ICollection<string> columnFilters, ICollection<string> valuesFilter)
        {
            object[] args = valuesFilter.ToArray<object>();
            string lambda = string.Empty, columnName = string.Empty;
            for (int i = 0; i < columnFilters.Count; i++)
            {
                lambda = columnFilters.ElementAt(i).ToString();
                columnName = lambda[(lambda.IndexOf('.') + 1)..];
                var valueFilter = args[i].ToString().Trim().ToUpper();
                switch (columnName.ToLower())
                {
                    case "employeenumber":
                        {
                            var employee = valueFilter;
                            query = query.Where(x => x.EmployeeNumber.ToUpper().Contains(employee));
                        }
                        break;
                    case "fullname":
                        {
                            var fullname = valueFilter;
                            query = query.Where(x => x.FullName.ToUpper().Contains(fullname));
                        }
                        break;
                    case "networkuser":
                        {
                            var starttime = valueFilter;
                            query = query.Where(x => x.NetworkUser.ToUpper().Contains(starttime));
                        }
                        break;
                    case "email":
                        {
                            var email = valueFilter;
                            query = query.Where(x => x.Email.ToUpper().Contains(email));
                        }
                        break;
                    case "userroledesc":
                        {
                            var permission = valueFilter;
                            query = query.Where(x => x.UserRoleDesc.ToUpper().Contains(permission));
                        }
                        break;
                    case "status":
                        {
                            var active = valueFilter.Equals("TRUE");
                            query = query.Where(x => x.Active.Equals(active));
                        }
                        break;
                    default:
                        break;
                }
            }
            return query;
        }

        /// <summary>
        /// Method to check if user exist with filter (region, site, building)
        /// </summary>
        /// <param name="userFilterDto">UserFilterDto</param>
        /// <returns>bool</returns>
        public async Task<bool> CheckIfExist(UserFilterDto userFilterDto)
        {
            IQueryable<UserDto> query = GetQueryFilterUser(userFilterDto);
            UserDto user = await query.FirstOrDefaultAsync();

            return user != null;
        }

        /// <summary>
        /// Query with filter (region, site, building, networkuser) and return user dto
        /// </summary>
        /// <param name="userFilterDto">UserFilterDto</param>
        /// <returns>UserDto</returns>
        private IQueryable<UserDto> GetQueryFilterUser(UserFilterDto userFilterDto)
        {
            IQueryable<UserDto> query =
                (from TblUser in _context.Users
                 join TblRole in _context.UserRoles
                 on TblUser.UserRoleId equals TblRole.Id

                 where TblUser.NetworkUser.ToUpper() == userFilterDto.Networkuser.ToUpper()
                 select new UserDto()
                 {
                     Id = TblUser.Id,
                     NetworkUser = TblUser.NetworkUser,
                     Email = TblUser.Email,
                     FullName = TblUser.FullName,
                     UserRoleDesc = TblRole.Description
                 }
                ).AsQueryable();

            return query;
        }

        /// <summary>
        /// Get user by network user and region, site and building
        /// </summary>
        /// <param name="userFilterDto">UserFilterDto</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> GetUserByNetworkAndFilters(UserFilterDto userFilterDto)
        {
            IQueryable<UserDto> query = GetQueryFilterUser(userFilterDto);

            UserDto user = await query.SingleOrDefaultAsync();

            return user;
        }

        /// <summary>
        /// Get user dto by id to Info
        /// </summary>
        /// <param name="userId">userId</param>
        /// <returns>UserDto</returns>
        public async Task<UserDto> GetUserInfoById(int userId)
        {
            IQueryable<UserDto> query = GetQueryUserDto();
            query = query.Where(u => u.Id == userId);

            var result = await Task.FromResult(query.AsNoTracking().FirstOrDefault());

            return result;
        }
    }
}
