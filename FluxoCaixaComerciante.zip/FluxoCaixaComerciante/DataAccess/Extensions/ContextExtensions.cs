﻿using FluxoCaixa.Models;
using FluxoCaixa.Models.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FluxoCaixa.DataAccess.Extensions
{
    /// <summary>
    /// Class with extensions of the context
    /// </summary>
    public static class ContextExtensions
    {
        private static List<Action<IMutableEntityType>> Conventions = new List<Action<IMutableEntityType>>();

        /// <summary>
        /// Method to remove one-to-many and many-to-many delete cascate convention
        /// </summary>
        /// <param name="builder">Model Builder</param>
        public static void AddRemoveOneAndManyToManyCascadeConvention(this ModelBuilder builder)
        {
            Conventions.Add(et => et.GetForeignKeys()
                .Where(fk => !fk.IsOwnership && fk.DeleteBehavior == DeleteBehavior.Cascade)
                .ToList()
                .ForEach(fk => fk.DeleteBehavior = DeleteBehavior.Restrict));
        }

        /// <summary>
        /// Method to apply all conventions
        /// </summary>
        /// <param name="builder">Model Builder</param>
        public static void ApplyConventions(this ModelBuilder builder)
        {
            foreach (var entityType in builder.Model.GetEntityTypes())
            {
                foreach (Action<IMutableEntityType> action in Conventions)
                    action(entityType);
            }

            Conventions.Clear();
        }

        /// <summary>
        /// Method to insert default values
        /// </summary>
        /// <param name="modelBuilder">Model Builder</param>
        public static void Seed(this ModelBuilder modelBuilder)
        {
            #region User Roles table

            modelBuilder.Entity<UserRole>().HasData(
                new UserRole
                {
                    Id = 1,
                    Description = "Adm",
                    Role = UserRoles.ADM,
                    UserCreate = "System"
                }
            );

            modelBuilder.Entity<UserRole>().HasData(
                new UserRole
                {
                    Id = 2,
                    Description = "User",
                    Role = UserRoles.USER,
                    UserCreate = "System"
                }
            );

            #endregion
        }
    }
}
