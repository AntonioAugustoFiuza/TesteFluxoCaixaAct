using FluxoCaixa.DataAccess.Extensions;
using FluxoCaixa.Models;
using FluxoCaixa.Models.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using FluxoCaixa.Models.GlobalFunction;
using FluxoCaixa.Models.DTOs;

namespace FluxoCaixa.DataAcess.Context
{
    /// <summary>
    /// Class with the context of the system
    /// </summary>
    public class SystemContext : DbContext
    {
        /// <summary>
        /// Contructor of the context
        /// </summary>
        /// <param name="options">DbContextOptions</param>
        public SystemContext(DbContextOptions<SystemContext> options) : base(options)
        {
        }

        #region "Entities" 

        /// <summary>
        /// Users Table
        /// </summary>
        public DbSet<User> Users { get; set; }
        /// <summary>
        /// UserRoles Table
        /// </summary>
        public DbSet<UserRole> UserRoles { get; set; }
        /// <summary>
        /// Lancs Table
        /// </summary>
        public DbSet<Lanc> Lancs { get; set; }
        
        #endregion

        /// <summary>
        /// Load Conventions, entities mapping and seed data
        /// </summary>
        /// <param name="modelBuilder">Model Builder</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region Conventions

            modelBuilder.AddRemoveOneAndManyToManyCascadeConvention();

            modelBuilder.ApplyConventions();

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(SystemContext).Assembly);

            #endregion

            #region "Entities" Mapping


            modelBuilder.ApplyConfiguration(new LancConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());
            modelBuilder.ApplyConfiguration(new UserRoleConfiguration());
           
            #endregion

            #region Seed Data

            modelBuilder.Seed();

            #endregion

            base.OnModelCreating(modelBuilder);
        }
    }
}