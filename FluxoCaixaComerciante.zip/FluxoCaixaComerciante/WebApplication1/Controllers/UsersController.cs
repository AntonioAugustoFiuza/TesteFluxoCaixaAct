﻿using FluxoCaixa.Interfaces.DataServices;
using FluxoCaixa.Models.AbsModels;
using FluxoCaixa.Models.Constants;
using FluxoCaixa.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    /// <summary>
    /// API controller User
    /// </summary>
    [ApiController]
    [Route("api/users"), Authorize]
    public class UsersController : ControllerBase
    {
        /// <summary>
        /// Property User service
        /// </summary>
        private readonly IUserDataService _userService;

        /// <summary>
        /// Default Constructor
        /// </summary>
        /// <param name="userService">User service</param>
        public UsersController(IUserDataService userService)
        {
            _userService = userService;
        }

        /// <summary>
        /// Get a user by id
        /// </summary>
        /// <param name="userId">The user Id</param>
        /// <returns>The user instance</returns>
        [HttpGet("{userId:int}")]
        public async Task<UserDto> GetById(int userId)
        {
            return await _userService.GetById(userId);
        }

        /// <summary>
        /// API method to get a user information by id using site parameters timezone
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPost("info/{userId:int}")]
        public async Task<IActionResult> GetUserInfoById(int userId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            UserDto userDto = await _userService.GetById(userId);

            return Ok(userDto);
        }

        /// <summary>
        /// Get a user by network user
        /// </summary>
        /// <param name="networkUser">Network User</param>
        /// <returns>User</returns>
        [HttpGet("network/{networkUser}"), AllowAnonymous]
        public async Task<UserDto> GetByNetworkUser(string networkUser)
        {
            return await _userService.GetByNetworkUser(networkUser);
        }

        /// <summary>
        /// Get a user by email
        /// </summary>
        /// <param name="email">Email</param>
        /// <returns>User</returns>
        [HttpGet("email/{email}"), AllowAnonymous]
        public async Task<UserDto> GetUserByEmail(string email)
        {
            return await _userService.GetUserByEmail(email);
        }

        /// <summary>
        /// Get user by network and filters
        /// </summary>
        /// <param name="userFilterDto"></param>
        /// <returns></returns>
        [HttpPost("network-filter")]
        public async Task<UserDto> GetByNetworkUserAndFilter([FromBody] UserFilterDto userFilterDto)
        {
            return await _userService.GetUserByNetworkAndFilters(userFilterDto);
        }

        /// <summary>
        /// Get all user roles
        /// </summary>
        /// <returns>List of User Roles></returns>
        [HttpGet("roles")]
        public async Task<ICollection<UserRoleDto>> GetUserRoles()
        {
            return await _userService.GetUserRoles();
        }

        /// <summary>
        /// Add a new user
        /// </summary>
        /// <param name="userDto">userDto</param>
        /// <returns>User</returns>
        [HttpPost, Authorize(Roles = UserRoles.ADM)]
        public async Task<IActionResult> Add([FromBody] UserDto userDto)
        {
            await Validate(userDto);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            UserDto resultDto = await _userService.Add(userDto);

            return Ok(resultDto);
        }

        /// <summary>
        /// Update a user
        /// </summary>
        /// <param name="userDto">userDto</param>
        /// <returns>User</returns>
        [HttpPut, Authorize(Roles = UserRoles.ADM)]
        public async Task<IActionResult> Update([FromBody] UserDto userDto)
        {
            await Validate(userDto);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            UserDto resultDto = await _userService.Update(userDto);

            return Ok(resultDto);
        }

        /// <summary>
        /// Activate a user
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>User</returns>
        [HttpPatch("{id:int}/activate"), Authorize(Roles = UserRoles.ADM)]
        public async Task<UserDto> Activate(int id)
        {
            return await _userService.Activate(id);
        }

        /// <summary>
        /// Inactivate a user
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>User</returns>
        [HttpPatch("{id:int}/inactivate"), Authorize(Roles = UserRoles.ADM)]
        public async Task<UserDto> Inactivate(int id)
        {
            return await _userService.Inactivate(id);
        }

        /// <summary>
        /// API method to check user exist
        /// </summary>
        /// <param name="userFilterDto">Filters of the datatable</param>
        /// <returns>List of parameters</returns>
        [HttpPost("user-exist")]
        public async Task<IActionResult> CheckUserExist([FromBody] UserFilterDto userFilterDto)
        {
            var result = await _userService.CheckIfExist(userFilterDto);
            return Ok(result);
        }

        /// <summary>
        /// Asynchronous method to validate a user model
        /// </summary>
        /// <param name="userDto">userDto</param>
        private async Task Validate(UserDto userDto)
        {
            if (await _userService.DuplicateExists(userDto))
            {
                string alertMsg = $"The network user >>>{userDto.NetworkUser}<<< already exists";
                ModelState.AddModelError(nameof(userDto.NetworkUser), alertMsg);
            }
        }

        /// <summary>
        /// Check if user exist in the system
        /// </summary>
        /// <param name="email">Email</param>
        /// <returns>Bool</returns>
        [HttpGet("checkif-userexist/{email}"), AllowAnonymous]
        public async Task<bool> CheckIfUserExist(string email)
        {
            return await _userService.CheckIfUserExist(email);
        }
    }
}