﻿using FluxoCaixa.Interfaces.DataServices;
using FluxoCaixa.Models.Constants;
using FluxoCaixa.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    /// <summary>
    /// API controller Lanc
    /// </summary>
    [ApiController]
    [Route("api/lanc"), Authorize]
    public class LancController : ControllerBase
    {
        /// <summary>
        /// Property Lanc Service
        /// </summary>
        private readonly ILancDataService _lancService;

        /// <summary>
        /// Default Constructor
        /// </summary>
        /// <param name="lancService">Lanc Service</param>
        public LancController(ILancDataService lancService)
        {
            _lancService = lancService;
        }

        /// <summary>
        /// Get a lanc by id
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>Lanc</returns>
        [HttpGet("{id}")]
        public async Task<LancDto> Get(int id)
        {
            return await _lancService.Get(id);
        }

        /// <summary>
        /// Get list of lancs
        /// </summary>
        /// <returns>List of lancs</returns>
        [HttpPost("all")]
        public async Task<IActionResult> GetAll()
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var resultList = await _lancService.List();

            return Ok(resultList);
        }

        /// <summary>
        /// Get list of lancs consolated by specified date
        /// </summary>
        /// <returns>List of lancs</returns>
        [HttpPost("consolated/{date}")]
        public async Task<IActionResult> GetAllConsolated(DateTime date)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var resultList = await _lancService.ListConsolated(date);

            return Ok(resultList);
        }

        /// <summary>
        /// Add a new lanc
        /// </summary>
        /// <param name="lancDto">Lanc Dto</param>
        /// <returns>lanc</returns>
        [HttpPost, Authorize(Roles = UserRoles.ADM)]
        public async Task<IActionResult> Add([FromBody] LancDto lancDto)
        {
            await Validate(lancDto);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            LancDto resultDto = await _lancService.Add(lancDto);

            return Ok(resultDto);
        }

        /// <summary>
        /// Update a lanc
        /// </summary>
        /// <param name="lancDto">Lanc Dto</param>
        /// <returns>Root Cause</returns>
        [HttpPut, Authorize(Roles = UserRoles.ADM)]
        public async Task<IActionResult> Update([FromBody] LancDto lancDto)
        {
            await Validate(lancDto);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            LancDto resultDto = await _lancService.Update(lancDto);

            return Ok(resultDto);
        }

        /// <summary>
        /// Asynchronous method to validate a lanc model
        /// </summary>
        /// <param name="lancDto">Lanc Dto</param>
        /// <returns>Task</returns>
        private async Task Validate(LancDto lancDto)
        {
            bool status = await _lancService.DuplicateExists(lancDto);
            if (status)
            {
                string alertMsg = $"Lanc ({lancDto.DescLanc}) already added to system";
                ModelState.AddModelError(nameof(lancDto.DescLanc), alertMsg);
            }
        }
    }
}