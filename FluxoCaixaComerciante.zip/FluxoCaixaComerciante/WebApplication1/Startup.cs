//var builder = WebApplication.CreateBuilder(args);

//// Add services to the container.

//builder.Services.AddControllers();
//// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

//var app = builder.Build();

//// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
//    app.UseSwagger();
//    app.UseSwaggerUI();
//}

//app.UseHttpsRedirection();

//app.UseAuthorization();

//app.MapControllers();

//app.Run();

//using Amazon.S3;
//using Amazon.Translate;
//using AutoMapper;
//using GlobalMrbTool.Infra.Extensions;
//using GlobalMrbTool.Infra.S3;
//using GlobalMrbTool.Infra.SmbFileShares;
//using GlobalMrbTool.Infra.Translate;
//using GlobalMrbTool.Interfaces.Aws;
//using GlobalMRBTool.DI;
//using GlobalMRBTool.DI.Mapping;
//using GlobalMRBTool.Interfaces.Aws;
//using GlobalMRBTool.Models.GlobalFunction;
using AutoMapper;
using FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Extensions;
using FluxoCaixa.DI;
using FluxoCaixa.DI.Mapping;
using Microsoft.EntityFrameworkCore;
using WebApi.Swagger;

namespace WebApi
{
    /// <summary>
    /// 
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// 
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// // This method gets called by the runtime. Use this method to add services to the container
        /// </summary>
        /// <param name="services">List of services</param>
        public void ConfigureServices(IServiceCollection services)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

            services.ConfigureData(Configuration);

            services.AddDefaultAWSOptions(Configuration.GetAWSOptions());

            services.AddOktaAuthentication(Configuration);

            var origins = Configuration["allowed-origins"] != null ? Configuration["allowed-origins"].Split(",") : Array.Empty<string>();

            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder
                    .WithOrigins(origins)
                    .AllowAnyMethod()
                    .AllowAnyHeader();
            }));

            services.AddControllers();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "AWS Lambda API",
                    Version = "v1",
                    Description = "Api for Fluxo Caixa Comerciante"
                });

                options.OperationFilter<DefaultHeaderFilter>();
            });

            //Simplest Approach to Add Auto Mapper is End
            services.AddAutoMapper(typeof(Startup));

            ////Auto Mapper Configuration Start
            var mapperConfig = new MapperConfiguration(mc =>
            {
                mc.AllowNullCollections = true;

                mc.AddProfile(new AutoMapping());
            });

            IMapper mapper = mapperConfig.CreateMapper();
            services.AddSingleton(mapper);

            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddConsole()
                    .AddFilter(DbLoggerCategory.Database.Command.Name, LogLevel.Information);
                loggingBuilder.AddDebug();
            });

            services.AddAWSLambdaHosting(LambdaEventSource.RestApi);
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline
        /// </summary>
        /// <param name="app">Application Builder</param>
        /// <param name="env">Environment</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IHttpContextAccessor accessor)
        {
            //GlobalFunctions.SetHttpContextAccessor(accessor);
            //HttpContextExtensions.SetDnsServerPort(Configuration["dns-server-port"])

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors("MyPolicy");

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "AWS Lambda API");
                options.RoutePrefix = string.Empty;
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
