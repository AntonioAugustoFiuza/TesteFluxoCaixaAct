﻿using FluxoCaixa.Models.Enums;
using Microsoft.Extensions.Configuration;

namespace FluxoCaixa.Infra.Configuration
{
    /// <summary>
    /// 
    /// </summary>
    public static class ConfigurationExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="secretName"></param>
        /// <param name="region"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        /// <exception cref="ArgumentException"></exception>
        public static IConfigurationBuilder AddApplicationSecretsFromAmazonSecretManager(this IConfigurationBuilder configuration, string secretName, string region)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }

            if (string.IsNullOrEmpty(secretName))
            {
                throw new ArgumentException("SecretName is not specified.");
            }

            var secretManagerConfigurationSource = new AmazonSecretManagerConfigurationSource(secretName, region);
            configuration.Add(secretManagerConfigurationSource);
            return configuration;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="projectType"></param>
        /// <returns></returns>
        public static IConfigurationBuilder AddApplicationSecretsFromEnvironmentVariables(this IConfigurationBuilder configuration,
            ProjectType projectType)
        {
            var environmentVariablesConfigurationSource = new EnvironmentVariablesConfigurationSource(projectType);
            configuration.Add(environmentVariablesConfigurationSource);
            return configuration;
        }
    }
}
