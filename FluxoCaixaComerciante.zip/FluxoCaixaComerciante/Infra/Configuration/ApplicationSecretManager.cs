﻿using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using System.Text.Json;

namespace FluxoCaixa.Infra.Configuration
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class ApplicationSecretManager : IDisposable
    {
        private readonly IAmazonSecretsManager _secretsManager;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="region"></param>
        public ApplicationSecretManager(string region)
        {
            var config = new AmazonSecretsManagerConfig { RegionEndpoint = RegionEndpoint.GetBySystemName(region) };
            _secretsManager = new AmazonSecretsManagerClient(config);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="secretId"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, string>> GetSecretAsync(string secretId)
        {
            var request = new GetSecretValueRequest { SecretId = secretId };
            var response = await _secretsManager.GetSecretValueAsync(request);
            return JsonSerializer.Deserialize<Dictionary<string, string>>(response.SecretString);
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            _secretsManager.Dispose();
        }
    }
}
