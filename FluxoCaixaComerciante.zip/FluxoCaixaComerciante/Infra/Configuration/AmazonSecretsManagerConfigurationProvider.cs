﻿using Microsoft.Extensions.Configuration;

namespace FluxoCaixa.Infra.Configuration
{
    /// <summary>
    /// 
    /// </summary>
    public class AmazonSecretsManagerConfigurationProvider : ConfigurationProvider
    {
        private readonly string _secretName;
        private readonly string _region;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="secretName"></param>
        /// <param name="region"></param>
        public AmazonSecretsManagerConfigurationProvider(string secretName, string region)
        {
            _secretName = secretName;
            _region = region;
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Load()
        {
            Dictionary<string, string> data;
            using (var secretManager = new ApplicationSecretManager(_region))
            {
                data = secretManager.GetSecretAsync(_secretName).Result;
            }

            Data = data;
        }
    }
}
