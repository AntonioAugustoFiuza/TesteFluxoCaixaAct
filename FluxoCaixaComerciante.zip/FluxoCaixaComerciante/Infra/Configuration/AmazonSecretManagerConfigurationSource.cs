﻿using Microsoft.Extensions.Configuration;

namespace FluxoCaixa.Infra.Configuration
{
    /// <summary>
    /// 
    /// </summary>
    public class AmazonSecretManagerConfigurationSource : IConfigurationSource
    {
        private readonly string _secretName;
        private readonly string _region;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="secretName"></param>
        /// <param name="region"></param>
        public AmazonSecretManagerConfigurationSource(string secretName, string region)
        {
            _secretName = secretName;
            _region = region;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new AmazonSecretsManagerConfigurationProvider(_secretName, _region);
        }
    }
}
