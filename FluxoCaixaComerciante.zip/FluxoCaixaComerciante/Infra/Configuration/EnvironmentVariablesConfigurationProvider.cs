﻿using FluxoCaixa.Models.Enums;
using Microsoft.Extensions.Configuration;

namespace FluxoCaixa.Infra.Configuration
{
    /// <summary>
    /// 
    /// </summary>
    public class EnvironmentVariablesConfigurationProvider : ConfigurationProvider
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly ProjectType _projectType;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="projectType"></param>
        public EnvironmentVariablesConfigurationProvider(ProjectType projectType)
        {
            _projectType = projectType;
        }

        /// <summary>
        /// 
        /// </summary>
        public override void Load()
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            data.Add("allowed-origins", Environment.GetEnvironmentVariable("allowed-origins"));
            data.Add("aws_environment", Environment.GetEnvironmentVariable("aws_environment"));

            switch (_projectType)
            {
                case ProjectType.WebApi:
                    {
                        #region AWS Environments variables

                        data.Add("okta_clientId", Environment.GetEnvironmentVariable("okta_clientId"));
                        data.Add("okta_issuer", Environment.GetEnvironmentVariable("okta_issuer"));
                        data.Add("db_host", Environment.GetEnvironmentVariable("db_host"));
                        data.Add("db_port", Environment.GetEnvironmentVariable("db_port"));
                        data.Add("db_name", Environment.GetEnvironmentVariable("db_name"));
                        data.Add("db_username", Environment.GetEnvironmentVariable("db_username"));
                        data.Add("db_password", Environment.GetEnvironmentVariable("db_password"));
                        data.Add("db_instanceIdentifier", Environment.GetEnvironmentVariable("db_instanceIdentifier"));
                        data.Add("db_engine", Environment.GetEnvironmentVariable("db_engine"));
                        #endregion
                    }
                    break;
            }

            Data = data;
        }
    }
}
