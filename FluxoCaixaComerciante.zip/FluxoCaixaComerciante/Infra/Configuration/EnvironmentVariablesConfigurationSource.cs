﻿using FluxoCaixa.Models.Enums;
using Microsoft.Extensions.Configuration;

namespace FluxoCaixa.Infra.Configuration
{
    /// <summary>
    /// 
    /// </summary>
    public class EnvironmentVariablesConfigurationSource : IConfigurationSource
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly ProjectType _projectType;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="projectType"></param>
        public EnvironmentVariablesConfigurationSource(ProjectType projectType)
        {
            _projectType = projectType;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new EnvironmentVariablesConfigurationProvider(_projectType);
        }
    }
}
