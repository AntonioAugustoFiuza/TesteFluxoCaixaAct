﻿using FluxoCaixa.Infra.Authentication.Okta;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Interfaces
{
    /// <summary>
    /// Interface Okta Service
    /// </summary>
    public interface IOktaService
    {
        /// <summary>
        /// Method validate token
        /// </summary>
        /// <param name="idToken">Token id</param>
        /// <param name="configurationManager">Configuration Manager</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns>OktaIntrospectResponse</returns>
        Task<OktaIntrospectResponse> ValidateToken(string idToken, IConfigurationManager<OpenIdConnectConfiguration> configurationManager, CancellationToken ct = default(CancellationToken));
    }
}
