﻿using Microsoft.AspNetCore.Authentication;

namespace FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Schemes
{
    /// <summary>
    /// Class to define default schema
    /// </summary>
    public class LocalAuthenticationOptions : AuthenticationSchemeOptions
    {
        /// <summary>
        /// Default Schema name
        /// </summary>
        public const string DefaultSchemaName = "LocalAuthenticationScheme";
    }
}
