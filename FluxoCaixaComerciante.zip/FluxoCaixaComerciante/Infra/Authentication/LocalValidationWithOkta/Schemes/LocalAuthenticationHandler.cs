﻿using FluxoCaixa.Infra.Authentication.Okta;
using FluxoCaixa.Models;
using FluxoCaixa.Models.Constants;
using FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ISystemClock = Microsoft.AspNetCore.Authentication.ISystemClock;
using FluxoCaixa.Interfaces.Repositories;

namespace FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Schemes
{
    /// <summary>
    /// Class to local authentication handler
    /// </summary>
    public class LocalAuthenticationHandler : AuthenticationHandler<LocalAuthenticationOptions>
    {
        /// <summary>
        /// Okta service
        /// </summary>
        private readonly IOktaService _oktaService;
        /// <summary>
        /// User repository
        /// </summary>
        private readonly IUserRepository _userRepository;
        /// <summary>
        /// Unauthorized Error message
        /// </summary>
        private string unauthorizedError;
        /// <summary>
        /// Configuration Manager OpenIdConnection config
        /// </summary>
        private readonly IConfigurationManager<OpenIdConnectConfiguration> _configurationManager;

        /// <summary>
        /// Default constructor
        /// </summary>
        /// <param name="options">Options Monitor</param>
        /// <param name="logger">Logger Factory</param>
        /// <param name="encoder">Url Encoder</param>
        /// <param name="clock">System Clock</param>
        /// <param name="oktaService">Okta service</param>
        /// <param name="userRepository"></param>
        /// <param name="configurationManager"></param>
        public LocalAuthenticationHandler(
            IOptionsMonitor<LocalAuthenticationOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IOktaService oktaService,
            IUserRepository userRepository,
        IConfigurationManager<OpenIdConnectConfiguration> configurationManager
            )
            : base(options, logger, encoder, clock)
        {
            _oktaService = oktaService;
            _userRepository = userRepository;
            _configurationManager = configurationManager;
        }

        /// <summary>
        /// Method to authentication
        /// </summary>
        /// <returns>Authenticate Result</returns>
        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var currentPath = Context.Request.Path;

            if (Request.Headers.ContainsKey("IsSwaggerRequest"))
            {
                Request.Headers.Add("Authorization", "AccessToken swagger IdToken swagger");
            }

            if (!Request.Headers.ContainsKey("Authorization"))
            {
                unauthorizedError = "Authorization header was not found.";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            var authorizationHeader = Request.Headers["Authorization"].ToString();
            if (string.IsNullOrWhiteSpace(authorizationHeader)
                || !authorizationHeader.Contains("AccessToken ")
                || !authorizationHeader.Contains("IdToken ")
                )

            {
                unauthorizedError = "Authorization header does not contains tokens.";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            var regex = new Regex("AccessToken (\\S*) IdToken (\\S*)");
            var matches = regex.Matches(authorizationHeader);

            if (matches.Count == 0)
            {
                unauthorizedError = "Authorization header format is invalid.";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            if (!Request.Headers.ContainsKey("NameUser"))
            {
                unauthorizedError = "NameUser has been not found in header request";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            if (!Request.Headers.ContainsKey("EmailUser"))
            {
                unauthorizedError = "EmailUser has been not found in header request";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            if (!Request.Headers.ContainsKey("IsSwaggerRequest"))
            {
                var idToken = matches[0].Groups[2].Value;
                var introspectResponse = await _oktaService.ValidateToken(idToken, _configurationManager);

                if (!introspectResponse.Active)
                {
                    unauthorizedError = $"Authorization id token is not valid. Details: {introspectResponse.Message}";
                    return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
                }
            }

            var oktaUserInfoResponse = new OktaUserInfoResponse()
            {
                Name = Request.Headers["NameUser"].ToString(),
                Email = Request.Headers["EmailUser"].ToString()
            };


            User user = await _userRepository.GetOneByFilterAsync(c => c.Email.ToUpper() == oktaUserInfoResponse.Email.ToUpper(),
                new Collection<string>() { "UserRole" }, null, false, true);

            if (user == null)
            {
                unauthorizedError = $"{oktaUserInfoResponse.Name}({oktaUserInfoResponse.Email}) is not registered in the system.";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }
            else if (!user.Active)
            {
                unauthorizedError = $"{oktaUserInfoResponse.Name}({oktaUserInfoResponse.Email}) is not active in the system.";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            var claims = GetClaims(oktaUserInfoResponse, user);

            if (claims == null || claims.Count == 0)
            {
                unauthorizedError = $"{oktaUserInfoResponse.Name}({oktaUserInfoResponse.Email}) has not permission to access the system.";
                return await Task.FromResult(AuthenticateResult.Fail(unauthorizedError));
            }

            var id = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(id);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);
            return await Task.FromResult(AuthenticateResult.Success(ticket));
        }

        /// <summary>
        /// Method to write an error message when a authentication fails
        /// </summary>
        /// <param name="properties">AuthenticationProperties</param>
        /// <returns>Task</returns>
        protected override Task HandleChallengeAsync(AuthenticationProperties properties)
        {
            Response.StatusCode = 401;

            if (!string.IsNullOrWhiteSpace(unauthorizedError))
                Response.WriteAsync(unauthorizedError);

            return Task.CompletedTask;
        }

        /// <summary>
        /// Method to define claim to user
        /// </summary>
        /// <param name="oktaUserInfoResponse">Okta User Info Response</param>
        /// <param name="user">User model</param>
        /// <returns>Claim</returns>
        private static List<Claim> GetClaims(OktaUserInfoResponse oktaUserInfoResponse, User user)
        {
            var claims = new List<Claim> { new Claim(ClaimTypes.Name, oktaUserInfoResponse.Name.ToString()) };

            if (user != null)
            {
                switch (user.UserRole.Role)
                {
                    case UserRoles.ADM:
                        {
                            claims.Add(new Claim(ClaimTypes.Role, UserRoles.ADM));
                        }
                        break;
                    case UserRoles.USER:
                        {
                            claims.Add(new Claim(ClaimTypes.Role, UserRoles.USER));
                        }
                        break;
                    default:
                        {
                            claims = null;
                        }
                        break;
                }
            }
            else
            {
                claims = null;
            }

            return claims;
        }
    }
}