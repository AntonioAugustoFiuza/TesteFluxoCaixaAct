﻿using FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Schemes;
using FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Services;
using FluxoCaixa.Models.GlobalFunction;
using FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Interfaces;
using FluxoCaixa.Infra.Authentication.Okta;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using System.Configuration;

namespace FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Extensions
{
    /// <summary>
    /// Static class LocalAuthenticationRegistration
    /// </summary>
    public static class LocalAuthenticationRegistration
    {
        /// <summary>
        /// Method to add okta authentication services and DI
        /// </summary>
        /// <param name="services">Service collection</param>
        /// <param name="configuration">configuration</param>
        public static void AddOktaAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            OktaJwtVerificationOptions oktaConfig = new OktaJwtVerificationOptions()
            {
                ClientId = configuration["okta_clientId"],
                Issuer = configuration["okta_issuer"]
            };

            var configurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                $"{oktaConfig.Issuer}/.well-known/openid-configuration",
                new OpenIdConnectConfigurationRetriever(),
                new HttpDocumentRetriever());

            services.AddSingleton(oktaConfig);
            services.AddSingleton<IConfigurationManager<OpenIdConnectConfiguration>>(configurationManager);
            services.AddSingleton<IOktaService, OktaService>();

            services.AddAuthentication(LocalAuthenticationOptions.DefaultSchemaName)
                .AddScheme<LocalAuthenticationOptions, LocalAuthenticationHandler>(
                    LocalAuthenticationOptions.DefaultSchemaName,
                    opts => 
                    {
                    });
        }
    }
}
