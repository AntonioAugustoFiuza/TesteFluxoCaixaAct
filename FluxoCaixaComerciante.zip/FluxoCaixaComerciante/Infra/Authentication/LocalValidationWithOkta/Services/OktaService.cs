﻿using FluxoCaixa.Infra.Authentication.Okta;
using FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Interfaces;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Threading;
using System.Threading.Tasks;

namespace FluxoCaixa.Infra.Authentication.LocalValidationWithOkta.Services
{
    /// <summary>
    /// Class to validate token
    /// </summary>
    public class OktaService : IOktaService
    {
        /// <summary>
        /// Okta Jwt Verification Options
        /// </summary>
        private readonly OktaJwtVerificationOptions _oktaConfig;

        /// <summary>
        /// Defaulf constructor
        /// </summary>
        /// <param name="oktaConfig"></param>
        public OktaService(OktaJwtVerificationOptions oktaConfig)
        {
            _oktaConfig = oktaConfig;
        }

        /// <summary>
        /// Method to check if token is valid or not
        /// </summary>
        /// <param name="idToken">Token id</param>
        /// <param name="configurationManager">Configuration Manager</param>
        /// <param name="ct">Cancellation token</param>
        /// <returns>OktaIntrospectResponse</returns>
        public async Task<OktaIntrospectResponse> ValidateToken(
            string idToken,
            IConfigurationManager<OpenIdConnectConfiguration> configurationManager,
            CancellationToken ct = default(CancellationToken))
        {
            var validatedToken = await ValidateAndDecode(idToken, configurationManager, ct);

            if (validatedToken == null)
            {
                return new OktaIntrospectResponse { Active = false, Message = "The token is invalid." };
            }

            var expectedAlg = SecurityAlgorithms.RsaSha256; //Okta uses RS256

            if (validatedToken.Header?.Alg == null || validatedToken.Header?.Alg != expectedAlg)
            {
                return new OktaIntrospectResponse { Active = false, Message = "The signature algorithm must be RS256." };
            }

            validatedToken.Payload.TryGetValue("aud", out var audienceValue);
            var audience = audienceValue?.ToString();
            if (string.IsNullOrEmpty(audience) || audience != _oktaConfig.ClientId)
            {
                return new OktaIntrospectResponse { Active = false, Message = "The ClientId is invalid." };
            }

            return new OktaIntrospectResponse { Active = true };
        }

        /// <summary>
        /// Method to validate and decode token
        /// </summary>
        /// <param name="idToken">token id</param>
        /// <param name="configurationManager">Configuration Manager</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns>JwtSecurityToken</returns>
        private async Task<JwtSecurityToken> ValidateAndDecode(
            string idToken,
            IConfigurationManager<OpenIdConnectConfiguration> configurationManager,
            CancellationToken ct = default(CancellationToken))
        {
            var discoveryDocument = await configurationManager.GetConfigurationAsync(ct);
            var signingKeys = discoveryDocument.SigningKeys;

            var validationParameters = new TokenValidationParameters
            {
                RequireExpirationTime = true,
                RequireSignedTokens = true,
                ValidateIssuer = true,
                ValidIssuer = _oktaConfig.Issuer,
                ValidateIssuerSigningKey = true,
                TryAllIssuerSigningKeys = true,
                IssuerSigningKeys = signingKeys,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(2),
                ValidateAudience = true,
                ValidAudience = _oktaConfig.ClientId
            };

            try
            {
                new JwtSecurityTokenHandler().ValidateToken(idToken, validationParameters, out var rawValidatedToken);

                return (JwtSecurityToken)rawValidatedToken;
            }
            catch (Exception ex)
            {
                Log.Warning(ex, $"Token for client with id {_oktaConfig.ClientId} is invalid.");
                return null;
            }
        }
    }
}
