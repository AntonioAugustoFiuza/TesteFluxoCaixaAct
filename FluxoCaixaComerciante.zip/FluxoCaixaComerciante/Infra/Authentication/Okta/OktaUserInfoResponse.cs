﻿namespace FluxoCaixa.Infra.Authentication.Okta
{
    /// <summary>
    /// Class OktaUserInfoResponse
    /// </summary>
    public class OktaUserInfoResponse
    {
        /// <summary>
        /// Property Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Property Email
        /// </summary>
        public string Email { get; set; }
    }
}
