﻿namespace FluxoCaixa.Infra.Authentication.Okta
{
    /// <summary>
    /// Class OktaIntrospectResponse
    /// </summary>
    public class OktaIntrospectResponse
    {
        /// <summary>
        /// Property Active
        /// </summary>
        public bool Active { get; set; }
        /// <summary>
        /// Property Message
        /// </summary>
        public string Message { get; set; }
    }
}
