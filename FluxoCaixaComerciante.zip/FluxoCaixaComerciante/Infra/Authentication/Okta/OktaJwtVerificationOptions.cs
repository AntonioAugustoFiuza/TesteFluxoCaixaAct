﻿namespace FluxoCaixa.Infra.Authentication.Okta
{
    /// <summary>
    /// Class OktaJwtVerificationOptions
    /// </summary>
    public class OktaJwtVerificationOptions
    {
        /// <summary>
        /// Property Issuer
        /// </summary>
        public string Issuer { get; set; }
        /// <summary>
        /// Property ClientId
        /// </summary>
        public string ClientId { get; set; }
    }
}
