﻿using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace WebApi.Swagger
{
    public class DefaultHeaderFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "IsSwaggerRequest",
                In = ParameterLocation.Header,
                Required = false,
                Example = new OpenApiString("true")
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "NameUser",
                In = ParameterLocation.Header,
                Required = true,
                Example = new OpenApiString("Antonio Fiuza")
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "EmailUser",
                In = ParameterLocation.Header,
                Required = true,
                Example = new OpenApiString("guto.fiuza@gmail.com")
            });
        }
    }
}
