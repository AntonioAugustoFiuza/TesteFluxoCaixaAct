using FluxoCaixa.Infra.Configuration;
using FluxoCaixa.Models.Enums;

namespace WebApi
{
    /// <summary>
    /// The Main function can be used to run the ASP.NET Core application locally using the Kestrel webserver.
    /// </summary>
    public class LocalEntryPoint
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        protected LocalEntryPoint()
        {
        }

        /// <summary>
        /// Static method to run start local application
        /// </summary>
        /// <param name="args">Array of arguments</param>
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        /// <summary>
        /// Static method to create host and set up some configurations and Startup class 
        /// </summary>
        /// <param name="args">Array of arguments</param>
        /// <returns>Host Builder</returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
                Host.CreateDefaultBuilder(args)
                    .ConfigureWebHostDefaults(webBuilder =>
                    {
                        webBuilder
                            .ConfigureAppConfiguration((hostingContext, config) =>
                            {
                                config.AddApplicationSecretsFromEnvironmentVariables(ProjectType.WebApi);
                            })
                            .UseStartup<Program>();
                    });
    }
}